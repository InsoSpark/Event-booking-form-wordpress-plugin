<?php
/**
 * Uninstall handler. Removes plugin data when the plugin is deleted.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Remove settings.
delete_option( 'ebp_settings' );
delete_option( 'ebp_version' );
delete_option( 'ebp_notice_dismissed' );

// Remove all bookings.
$bookings = get_posts(
	array(
		'post_type'      => 'ebp_booking',
		'numberposts'    => -1,
		'post_status'    => 'any',
		'fields'         => 'ids',
	)
);

if ( ! empty( $bookings ) ) {
	foreach ( $bookings as $booking_id ) {
		wp_delete_post( $booking_id, true );
	}
}
