<?php
/**
 * Plugin Name:       Event Booking Pro
 * Plugin URI:        https://insospark.com
 * Description:       Fully dynamic event booking system with PayPal & Stripe payments (no webhooks required) and email notifications. Configure everything from the WordPress admin.
 * Version:           1.0.0
 * Author:            Akib
 * Author URI:        https://insospark.com
 * Developer:         InsoSpark
 * Text Domain:       event-booking-pro
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

define( 'EBP_VERSION', '1.0.0' );
define( 'EBP_PLUGIN_FILE', __FILE__ );
define( 'EBP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'EBP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'EBP_SLUG', 'event-booking-pro' );
define( 'EBP_CPT', 'ebp_booking' );

require_once EBP_PLUGIN_DIR . 'includes/class-ebp-loader.php';
EBP_Loader::instance();

/**
 * Activation hook. Runs directly on plugin activation (before plugins_loaded),
 * so it only does standalone work: defaults, version option, rewrite flush.
 */
register_activation_hook( __FILE__, 'ebp_activate' );
function ebp_activate() {
	require_once EBP_PLUGIN_DIR . 'includes/class-ebp-activator.php';
	EBP_Activator::activate();
}

register_deactivation_hook( __FILE__, 'ebp_deactivate' );
function ebp_deactivate() {
	require_once EBP_PLUGIN_DIR . 'includes/class-ebp-deactivator.php';
	EBP_Deactivator::deactivate();
}
