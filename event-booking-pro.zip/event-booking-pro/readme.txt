=== Event Booking Pro ===
Contributors: akib, insospark
Tags: booking, events, registration, payments, paypal, stripe
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Fully dynamic event booking system with PayPal & Stripe payments (no webhooks) and email notifications.

== Description ==

Event Booking Pro is a complete, settings-driven event booking plugin. Configure the event, packages, add-ons, pricing, payment gateways and email templates entirely from the WordPress admin — then drop the `[event_booking_pro]` shortcode on any page to show a beautiful 4-step registration wizard.

= Features =

* **Dynamic settings** — change event name, dates, venue, registration deadline, currency, refund policy and more from the backend.
* **Packages & add-ons** — add, remove and reorder unlimited packages and optional add-ons with prices and descriptions.
* **Payment plans** — offer Pay in Full, Deposit (% configurable) and Installment Plan (count configurable).
* **PayPal gateway** — paste your REST App Client ID + Secret. No webhooks required; payments are captured immediately.
* **Stripe gateway** — paste your Publishable + Secret keys. Embedded card form accepts Visa, Mastercard, Amex and more. No webhooks required.
* **Email notifications** — customer confirmation, payment received, and admin notifications with fully editable templates and placeholders.
* **Bookings manager** — view, search, filter and update every booking from a dedicated admin screen.
* **Appearance settings** — primary/accent/button/background colors, font families, early-bird banner, "Book Hotel" button, custom CSS.

= Usage =

1. Install and activate the plugin.
2. Go to **Event Booking → Settings** and configure General, Packages & Add-Ons, Payment, Email and Appearance.
3. Paste your PayPal Client ID + Secret and/or Stripe Publishable + Secret keys and enable the gateway.
4. Add the shortcode `[event_booking_pro]` to any page or post.
5. Manage bookings under **Event Booking → Bookings**.

= Developer ==

Developer: InsoSpark
Author: Akib
Version: 1.0.0

== Changelog ==

= 1.0.0 =
* Initial release.
