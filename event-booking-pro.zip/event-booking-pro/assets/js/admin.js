/* Event Booking Pro — admin JS: repeatable rows + bookings meta box */
(function ($) {
	'use strict';

	/* ------------------------------------------------------- repeaters */
	document.querySelectorAll('[data-repeater]').forEach(function (root) {
		var rowsWrap = root.querySelector('[data-rows]');
		var template = root.querySelector('[data-template]');
		if (!rowsWrap || !template) { return; }

		var rows = function () {
			return Array.prototype.slice.call(rowsWrap.querySelectorAll('[data-row]'));
		};

		var bindRow = function (row) {
			var name = row.querySelector('.ebp-row-name');
			var title = row.querySelector('.ebp-row-title');
			if (name && title) {
				name.addEventListener('input', function () { title.textContent = name.value || title.textContent; });
			}
			var rm = row.querySelector('[data-remove]');
			if (rm) {
				rm.addEventListener('click', function () { row.remove(); });
			}
		};

		rows().forEach(bindRow);

		var addBtn = root.querySelector('[data-add]');
		if (addBtn) {
			addBtn.addEventListener('click', function () {
				var clone = template.cloneNode(true);
				clone.removeAttribute('data-template');
				clone.style.display = '';
				var index = rows().length;
				clone.querySelectorAll('[name]').forEach(function (field) {
					field.name = field.name.replace('__i__', index);
				});
				rowsWrap.appendChild(clone);
				bindRow(clone);
				clone.scrollIntoView({ behavior: 'smooth', block: 'center' });
			});
		}

		if (window.jQuery && typeof jQuery.fn.sortable === 'function') {
			jQuery(rowsWrap).sortable({
				items: '[data-row]',
				handle: '.ebp-drag',
				placeholder: 'ebp-row-placeholder',
				update: function () {
					/* reindex names to match order */
					jQuery(rowsWrap).find('[data-row]').each(function (i) {
						var idx = i;
						jQuery(this).find('[name]').each(function () {
							this.name = this.name.replace(/\[\d+\]\[/, '[' + idx + '][');
						});
					});
				}
			});
		}
	});

	/* color pickers */
	var colorInputs = document.querySelectorAll('.ebp-color');
	if (colorInputs.length) {
		if (window.jQuery && jQuery.fn.wpColorPicker) {
			colorInputs.forEach(function (input) { jQuery(input).wpColorPicker(); });
		} else if (window.wp && wp.colorPicker) {
			colorInputs.forEach(function (input) { wp.colorPicker.initialize(input); });
		}
	}

	/* ------------------------------------------------- booking meta box */
	var EBP_ADMIN = window.EBP_ADMIN;
	if (!EBP_ADMIN || !EBP_ADMIN.postId) { return; }

	var postId = EBP_ADMIN.postId;
	var msgEl = document.querySelector('.ebp-admin-msg');

	function adminMsg(text, isError) {
		if (!msgEl) { return; }
		msgEl.textContent = text;
		msgEl.style.color = isError ? '#d63638' : '#2fb768';
	}

	var statusSelect = document.getElementById('ebp-status');
	var saveBtn = document.getElementById('ebp-save-status');

	if (saveBtn && statusSelect) {
		saveBtn.addEventListener('click', function () {
			var status = statusSelect.value;
			adminMsg('');
			saveBtn.disabled = true;
			fetch(EBP_ADMIN.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: 'action=ebp_admin_update_booking&nonce=' + encodeURIComponent(EBP_ADMIN.nonce) +
					'&booking_id=' + postId + '&status=' + encodeURIComponent(status)
			}).then(function (r) { return r.json(); }).then(function (res) {
				saveBtn.disabled = false;
				if (res.success) {
					adminMsg('Status updated to "' + res.data.label + '".');
					var badge = document.querySelector('.row-title');
					if (badge) { badge.textContent = ''; }
				} else {
					adminMsg(res.data && res.data.message ? res.data.message : 'Failed.', true);
				}
			}).catch(function () {
				saveBtn.disabled = false;
				adminMsg('Request failed.', true);
			});
		});
	}

	document.querySelectorAll('[data-ebp-resend]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var type = btn.getAttribute('data-ebp-resend');
			adminMsg('');
			btn.disabled = true;
			fetch(EBP_ADMIN.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: 'action=ebp_admin_resend_email&nonce=' + encodeURIComponent(EBP_ADMIN.nonce) +
					'&booking_id=' + postId + '&email_type=' + encodeURIComponent(type)
			}).then(function (r) { return r.json(); }).then(function (res) {
				btn.disabled = false;
				adminMsg(res.success ? (res.data.message || 'Email sent.') : (res.data.message || 'Failed.'), !res.success);
			}).catch(function () {
				btn.disabled = false;
				adminMsg('Request failed.', true);
			});
		});
	});
})(jQuery);
