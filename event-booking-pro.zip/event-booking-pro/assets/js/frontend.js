/* Event Booking Pro — frontend wizard + PayPal/Stripe payment flows */
(function () {
	'use strict';

	var EBP = window.EBP;
	if (!EBP) {
		return;
	}

	/* ---------------------------------------------------------------- state */
	var members = [];
	var memberIdSeq = 0;
	var pkg = {};
	var addon = {};
	var plan = 'full';
	var gateway = null;
	var booking = null;        // { booking_id, due, due_fmt, ... }
	var stripeInstance = null;
	var stripeCard = null;
	var stripeClientSecret = null;
	var paypalRendered = false;
	var paying = false;

	EBP.packages.forEach(function (p, i) { pkg['pkg_' + i] = 0; });
	EBP.addons.forEach(function (a, i) { addon['addon_' + i] = 0; });

	if (!EBP.plans.full && EBP.plans.deposit) { plan = 'deposit'; }
	else if (!EBP.plans.full && !EBP.plans.deposit && EBP.plans.installment) { plan = 'installment'; }

	/* ------------------------------------------------------------ helpers */
	function $(id) { return document.getElementById(id); }

	function money(n) {
		n = Math.round(Number(n) * 100) / 100;
		var parts = n.toFixed(2).split('.');
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
		return EBP.currency.symbol + parts.join('.');
	}

	function showError(msg) {
		var el = $('ebp-error');
		if (el) {
			el.textContent = msg;
			el.classList.add('visible');
			var wizard = document.querySelector('.ebp-wizard');
			if (wizard) { wizard.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
		}
	}

	function clearError() {
		var el = $('ebp-error');
		if (el) { el.classList.remove('visible'); }
	}

	function post(action, data) {
		var body = new FormData();
		body.append('action', action);
		body.append('nonce', EBP.nonce);
		Object.keys(data || {}).forEach(function (k) {
			var value = data[k];
			if (value !== null && typeof value === 'object') {
				value = JSON.stringify(value);
			}
			body.append(k, value);
		});
		return fetch(EBP.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (r) { return r.json(); });
	}

	function showStep(n) {
		document.querySelectorAll('.ebp-step').forEach(function (p) {
			p.classList.toggle('active', parseInt(p.getAttribute('data-step'), 10) === n);
		});
		document.querySelectorAll('#ebp-progress .ebp-seg').forEach(function (s, i) {
			s.classList.toggle('done', i < n);
		});
		clearError();
		var wizard = document.querySelector('.ebp-wizard');
		if (wizard) { wizard.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
	}

	function currentStep() {
		var el = document.querySelector('.ebp-step.active');
		return el ? parseInt(el.getAttribute('data-step'), 10) : 1;
	}

	/* ---------------------------------------------------------- attendees */
	function renderMembers() {
		var wrap = $('ebp-members');
		if (!wrap) { return; }
		wrap.innerHTML = '';
		if (members.length === 0) {
			var hint = document.createElement('p');
			hint.className = 'ebp-empty-hint';
			hint.textContent = 'Add yourself and everyone attending with you.';
			wrap.appendChild(hint);
			return;
		}
		members.forEach(function (m) {
			var div = document.createElement('div');
			div.className = 'ebp-member-card';
			div.innerHTML =
				'<button type="button" class="ebp-rm" onclick="EBPremoveMember(' + m.id + ')">\u2715</button>' +
				'<div class="ebp-field-row">' +
					'<div class="ebp-field"><label>First Name</label><input type="text" data-m="first" placeholder="First name"></div>' +
					'<div class="ebp-field"><label>Last Name</label><input type="text" data-m="last" placeholder="Last name"></div>' +
				'</div>' +
				'<div class="ebp-field-row">' +
					'<div class="ebp-field"><label>Age Group</label><select data-m="age_group">' + ageOptions() + '</select></div>' +
					'<div class="ebp-field"><label>T-Shirt Size</label><select data-m="shirt_size">' + shirtOptions() + '</select></div>' +
				'</div>' +
				'<div class="ebp-field-row">' +
					'<div class="ebp-field"><label>Meal / Allergy Info</label><input type="text" data-m="meal" placeholder="e.g. vegetarian, nut allergy"></div>' +
					'<div class="ebp-field"><label>Accessibility Needs</label><input type="text" data-m="access" placeholder="Optional"></div>' +
				'</div>' +
				'<div class="ebp-field"><label>Relationship / Family Branch</label><input type="text" data-m="relation" placeholder="e.g. Daughter, Nephew"></div>';
			wrap.appendChild(div);
		});
	}

	function ageOptions() {
		return EBP.ageGroups.map(function (g) { return '<option>' + g + '</option>'; }).join('');
	}

	function shirtOptions() {
		return EBP.shirtSizes.map(function (s) { return '<option>' + s + '</option>'; }).join('');
	}

	function collectAttendees() {
		var out = [];
		var cards = document.querySelectorAll('.ebp-member-card');
		cards.forEach(function (card) {
			var a = {};
			card.querySelectorAll('[data-m]').forEach(function (input) {
				a[input.getAttribute('data-m')] = input.value.trim();
			});
			out.push(a);
		});
		return out;
	}

	/* ------------------------------------------------------------ pricing */
	function calcTotal() {
		var total = 0;
		Object.keys(pkg).forEach(function (k) {
			var i = parseInt(k.replace('pkg_', ''), 10);
			if (EBP.packages[i]) { total += Number(EBP.packages[i].price) * pkg[k]; }
		});
		Object.keys(addon).forEach(function (k) {
			var i = parseInt(k.replace('addon_', ''), 10);
			if (EBP.addons[i]) { total += Number(EBP.addons[i].price) * addon[k]; }
		});
		return total;
	}

	function dueFor(total, p) {
		p = p || plan;
		if (p === 'deposit') { return Math.round(total * EBP.plans.deposit_percent) / 100; }
		if (p === 'installment') { return Math.round((total / EBP.plans.installment_count) * 100) / 100; }
		return total;
	}

	function updateTotals() {
		var total = calcTotal();
		var due = dueFor(total);
		var balance = Math.max(0, total - due);
		var targets = {
			'ebp-runningTotal': total,
			'ebp-finalTotal': total,
			'ebp-dueToday': due,
			'ebp-remBalance': balance
		};
		Object.keys(targets).forEach(function (id) {
			var el = $(id);
			if (el) { el.textContent = money(targets[id]); }
		});
	}

	/* ------------------------------------------------------ payment plan */
	function EBPselectPlan(p) {
		plan = p;
		document.querySelectorAll('.ebp-pay-opt').forEach(function (b) {
			b.classList.toggle('sel', b.getAttribute('data-plan') === p);
		});
		updateTotals();
	}

	/* ------------------------------------------------------------ gateway */
	function EBPselectGateway(g) {
		if (booking) { return; } /* locked after booking is created */
		gateway = g;
		document.querySelectorAll('.ebp-gateway-opt').forEach(function (b) {
			b.classList.toggle('sel', b.getAttribute('data-gateway') === g);
		});
		document.querySelectorAll('.ebp-gateway-panel').forEach(function (p) {
			p.classList.remove('active');
		});
		$('ebp-' + g + '-panel').classList.add('active');
	}

	function pickGateway() {
		if (booking && booking.gateways && booking.gateways.length > 0 && gateway === null) {
			gateway = booking.gateways[0];
		}
		if (!gateway) {
			var gws = document.querySelectorAll('.ebp-gateway-opt');
			if (gws.length) { gateway = gws[0].getAttribute('data-gateway'); }
		}
		return gateway;
	}

	/* -------------------------------------------------------------- steps */
	function EBPnextStep(current) {
		if (current === 1) {
			var first = $('ebp-first').value.trim();
			var last = $('ebp-last').value.trim();
			var email = $('ebp-email').value.trim();
			var validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
			if (!first || !last || !validEmail) {
				showError(EBP.i18n.fillRequired);
				return;
			}
		}
		updateTotals();
		showStep(current + 1);
	}

	function EBPprevStep(current) {
		showStep(current - 1);
	}

	function EBPaddMember() {
		members.push({ id: memberIdSeq++ });
		renderMembers();
	}

	function EBPremoveMember(id) {
		members = members.filter(function (m) { return m.id !== id; });
		renderMembers();
	}

	function EBPchQty(key, delta) {
		pkg[key] = Math.max(0, (pkg[key] || 0) + delta);
		var el = $('ebp-q-' + key);
		if (el) { el.textContent = pkg[key]; }
		updateTotals();
	}

	function EBPchAddon(key, delta) {
		addon[key] = Math.max(0, (addon[key] || 0) + delta);
		var el = $('ebp-a-' + key);
		if (el) { el.textContent = addon[key]; }
		updateTotals();
	}

	/* ---------------------------------------------------------- submit */
	function EBPsubmitRegistration() {
		if (paying) { return; }

		if (booking && booking.needs_payment && gateway === 'stripe') {
			payWithStripe();
			return;
		}

		clearError();
		var btn = $('ebp-submit');
		if (!btn) { return; }
		var original = btn.textContent;
		btn.disabled = true;
		btn.innerHTML = '<span class="spinner"></span> ' + EBP.i18n.processing;

		var payload = {
			first_name: $('ebp-first').value.trim(),
			last_name: $('ebp-last').value.trim(),
			email: $('ebp-email').value.trim(),
			phone: $('ebp-phone').value.trim(),
			branch: $('ebp-branch') ? $('ebp-branch').value : '',
			address: $('ebp-address').value.trim(),
			plan: plan,
			packages: pkg,
			addons: addon,
			attendees: collectAttendees()
		};

		post('ebp_create_booking', payload).then(function (res) {
			btn.disabled = false;
			btn.textContent = original;
			if (!res.success) {
				showError(res.data && res.data.message ? res.data.message : EBP.i18n.error);
				return;
			}
			booking = res.data;
			$('ebp-finalTotal').textContent = booking.total_fmt;
			$('ebp-dueToday').textContent = booking.due_fmt;
			$('ebp-remBalance').textContent = booking.balance_fmt;

			if (!booking.needs_payment) {
				showSuccess();
				return;
			}

			lockPaymentUI();
			var chosen = pickGateway();
			if (!chosen) {
				showError(EBP.i18n.noGateway);
				return;
			}
			initGateway(chosen);
		}).catch(function () {
			btn.disabled = false;
			btn.textContent = original;
			showError(EBP.i18n.error);
		});
	}

	function lockPaymentUI() {
		document.querySelectorAll('.ebp-pay-opt').forEach(function (b) { b.disabled = true; });
		document.querySelectorAll('.ebp-gateway-opt').forEach(function (b) { b.disabled = true; });
	}

	function initGateway(g) {
		gateway = g;
		document.querySelectorAll('.ebp-gateway-panel').forEach(function (p) { p.classList.remove('active'); });
		var panel = $('ebp-' + g + '-panel');
		if (panel) { panel.classList.add('active'); }

		if (g === 'stripe') {
			initStripe();
		} else if (g === 'paypal') {
			initPaypal();
		}
	}

	/* ----------------------------------------------------------- stripe */
	function initStripe() {
		var btn = $('ebp-submit');
		if (btn) { btn.textContent = EBP.i18n.payNow + ' ' + booking.due_fmt; }

		if (window.Stripe && EBP.gateways.stripe.publishable) {
			stripeInstance = window.Stripe(EBP.gateways.stripe.publishable);
			var els = stripeInstance.elements();
			stripeCard = els.create('card', { style: { base: { fontSize: '15px', color: '#1B2733' } } });
			stripeCard.mount('#ebp-card-element');
			stripeCard.on('change', function (event) {
				$('ebp-card-errors').textContent = event.error ? event.error.message : '';
			});
		} else if (!stripeInstance) {
			showError(EBP.i18n.error);
			return;
		}

		post('ebp_stripe_intent', { booking_id: booking.booking_id }).then(function (res) {
			if (!res.success) {
				showError(res.data && res.data.message ? res.data.message : EBP.i18n.error);
				return;
			}
			stripeClientSecret = res.data.client_secret;
		}).catch(function () {
			showError(EBP.i18n.error);
		});
	}

	function payWithStripe() {
		if (paying || !stripeInstance || !stripeCard || !stripeClientSecret) { return; }
		paying = true;
		var btn = $('ebp-submit');
		if (btn) { btn.disabled = true; }

		stripeInstance.confirmCardPayment(stripeClientSecret, {
			payment_method: { card: stripeCard }
		}).then(function (result) {
			if (result.error) {
				paying = false;
				if (btn) { btn.disabled = false; }
				$('ebp-card-errors').textContent = result.error.message;
				return;
			}
			finalizePayment('ebp_stripe_confirm', {
				booking_id: booking.booking_id,
				intent_id: result.paymentIntent.id
			});
		});
	}

	/* ----------------------------------------------------------- paypal */
	function initPaypal() {
		var btn = $('ebp-submit');
		if (btn) { btn.style.display = 'none'; }

		var render = function () {
			if (paypalRendered || !window.paypal || !window.paypal.Buttons) { return false; }
			paypalRendered = true;
			window.paypal.Buttons({
				style: { layout: 'vertical', color: 'gold', shape: 'rect', label: 'paypal' },
				createOrder: function () {
					return post('ebp_paypal_create_order', { booking_id: booking.booking_id })
						.then(function (res) {
							if (!res.success) {
								showError(res.data && res.data.message ? res.data.message : EBP.i18n.error);
								throw new Error(res.data && res.data.message ? res.data.message : EBP.i18n.error);
							}
							return res.data.order_id;
						});
				},
				onApprove: function (data) {
					return finalizePayment('ebp_paypal_capture', {
						booking_id: booking.booking_id,
						order_id: data.orderID
					});
				},
				onError: function () {
					showError(EBP.i18n.error);
				}
			}).render('#ebp-paypal-buttons');
			return true;
		};

		if (!render()) {
			var attempts = 0;
			var timer = setInterval(function () {
				attempts++;
				if (render() || attempts > 20) { clearInterval(timer); }
			}, 250);
		}
	}

	/* ------------------------------------------------------- finalize */
	function finalizePayment(action, data) {
		paying = true;
		return post(action, data).then(function (res) {
			if (!res.success) {
				paying = false;
				showError(res.data && res.data.message ? res.data.message : EBP.i18n.error);
				return;
			}
			booking = res.data;
			showSuccess();
		}).catch(function () {
			paying = false;
			showError(EBP.i18n.error);
		});
	}

	/* ------------------------------------------------------- success */
	function showSuccess() {
		var row = function (label, value) {
			return '<div class="ebp-row"><span>' + label + '</span><span>' + value + '</span></div>';
		};

		$('ebp-regNo').textContent = booking.reg_no;
		$('ebp-confirmDetails').innerHTML =
			row('Primary Registrant', booking.name) +
			row('Family Branch', ($('ebp-branch') ? $('ebp-branch').value : '—')) +
			row('Household Size', booking.headcount) +
			row('Payment Plan', booking.plan_label) +
			row('Reservation Total', booking.total_fmt) +
			row('Amount Paid', booking.due_fmt) +
			row('Balance Due', booking.balance_fmt);

		var msg = (EBP.config.confirm_message || '').replace('{event_name}', 'the event');
		$('ebp-confirmMessage').textContent = msg;

		showStep(5);
	}

	/* ------------------------------------------------------------ init */
	renderMembers();
	updateTotals();

	/* Initial gateway highlight (before booking exists). */
	(function initialGateway() {
		var options = document.querySelectorAll('.ebp-gateway-opt');
		if (options.length) {
			EBPselectGateway(options[0].getAttribute('data-gateway'));
		}
	})();

	window.EBPnextStep = EBPnextStep;
	window.EBPprevStep = EBPprevStep;
	window.EBPaddMember = EBPaddMember;
	window.EBPremoveMember = EBPremoveMember;
	window.EBPchQty = EBPchQty;
	window.EBPchAddon = EBPchAddon;
	window.EBPselectPlan = EBPselectPlan;
	window.EBPselectGateway = EBPselectGateway;
	window.EBPsubmitRegistration = EBPsubmitRegistration;
})();
