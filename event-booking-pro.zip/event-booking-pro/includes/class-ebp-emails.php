<?php
/**
 * Email notification system. Three message types, fully editable templates
 * with placeholders, sent through wp_mail.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Emails {

	const EMAIL_TYPES = array( 'confirmation', 'payment', 'admin' );

	/**
	 * Send a confirmation email to the customer (on booking creation).
	 *
	 * @param int $booking_id Booking post ID.
	 * @return bool
	 */
	public function send_confirmation( $booking_id ) {
		if ( '1' !== (string) ebp_settings( 'email.send_confirmation' ) ) {
			return true;
		}
		return $this->send( $booking_id, 'confirmation' );
	}

	/**
	 * Send a payment-received email to the customer.
	 *
	 * @param int $booking_id Booking post ID.
	 * @return bool
	 */
	public function send_payment_received( $booking_id ) {
		if ( '1' !== (string) ebp_settings( 'email.send_payment' ) ) {
			return true;
		}
		return $this->send( $booking_id, 'payment' );
	}

	/**
	 * Send an admin notification.
	 *
	 * @param int    $booking_id Booking post ID.
	 * @param string $event      Event label (new/payment).
	 * @return bool
	 */
	public function send_admin_notification( $booking_id, $event = 'new' ) {
		if ( '1' !== (string) ebp_settings( 'email.send_admin' ) ) {
			return true;
		}
		$recipients = $this->admin_recipients();
		if ( empty( $recipients ) ) {
			return true;
		}
		return $this->send( $booking_id, 'admin', $recipients );
	}

	/**
	 * Send an email of the given type.
	 *
	 * @param int    $booking_id Booking post ID.
	 * @param string $type       Email type.
	 * @param array  $to_override Recipients (defaults to customer email).
	 * @return bool
	 */
	public function send( $booking_id, $type, $to_override = array() ) {
		if ( ! in_array( $type, self::EMAIL_TYPES, true ) ) {
			return false;
		}

		$booking = EBP_Booking::get( $booking_id );
		if ( ! $booking ) {
			return false;
		}

		$data    = $booking->data;
		$email   = isset( $data['email'] ) ? $data['email'] : '';
		$to      = ! empty( $to_override ) ? $to_override : array( $email );
		$to      = array_values( array_unique( array_filter( $to, 'is_email' ) ) );

		if ( empty( $to ) ) {
			return false;
		}

		$subject = (string) ebp_settings( 'email.subject_' . $type );
		$body    = (string) ebp_settings( 'email.body_' . $type );
		$replace = $this->placeholders( $data, $type, $booking_id );

		$subject = strtr( $subject, $replace );
		$body    = strtr( $body, $replace );
		$html    = $this->wrap_html( $body );

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $this->from_name() . ' <' . $this->from_email() . '>',
		);

		$sent = true;
		foreach ( $to as $recipient ) {
			if ( ! wp_mail( $recipient, $subject, $html, $headers ) ) {
				$sent = false;
			}
		}
		return $sent;
	}

	/**
	 * Admin notification recipients.
	 *
	 * @return array
	 */
	private function admin_recipients() {
		$raw = (string) ebp_settings( 'email.admin_emails' );
		$list = array();
		foreach ( explode( ',', $raw ) as $item ) {
			$item = trim( $item );
			if ( is_email( $item ) ) {
				$list[] = $item;
			}
		}
		if ( empty( $list ) ) {
			$list[] = get_option( 'admin_email' );
		}
		return $list;
	}

	/**
	 * Build the placeholder map for a booking.
	 *
	 * @param array  $data       Booking data.
	 * @param string $type       Email type.
	 * @param int    $booking_id Booking post ID.
	 * @return array
	 */
	private function placeholders( $data, $type, $booking_id ) {
		$g = ebp_settings( 'general' );

		$name      = ( isset( $data['first_name'] ) ? $data['first_name'] : '' ) . ' ' . ( isset( $data['last_name'] ) ? $data['last_name'] : '' );
		$total     = isset( $data['totals']['total'] ) ? ebp_money( $data['totals']['total'] ) : '—';
		$due       = isset( $data['totals']['due'] ) ? ebp_money( $data['totals']['due'] ) : '—';
		$balance   = isset( $data['totals']['balance'] ) ? ebp_money( $data['totals']['balance'] ) : '—';
		$txn       = isset( $data['payment']['transaction_id'] ) ? $data['payment']['transaction_id'] : '';
		$gateway   = isset( $data['payment']['gateway'] ) ? $data['payment']['gateway'] : '';
		$gateway_l = $gateway ? ucfirst( $gateway ) : __( 'Online', 'event-booking-pro' );
		$status    = isset( $data['status'] ) ? $data['status'] : EBP_Booking::get_status( $booking_id );

		$placeholder = array(
			'{event_name}'      => $g['event_name'],
			'{event_date}'      => $g['event_date'],
			'{venue_name}'      => $g['venue_name'],
			'{venue_address}'   => $g['venue_address'],
			'{reg_deadline}'    => $g['reg_deadline'],
			'{refund_policy}'   => $g['refund_policy'],
			'{site_name}'       => get_bloginfo( 'name' ),
			'{site_url}'        => home_url(),
			'{reg_no}'          => isset( $data['reg_no'] ) ? $data['reg_no'] : '—',
			'{name}'            => $name,
			'{first_name}'      => isset( $data['first_name'] ) ? $data['first_name'] : '',
			'{last_name}'       => isset( $data['last_name'] ) ? $data['last_name'] : '',
			'{email}'           => isset( $data['email'] ) ? $data['email'] : '',
			'{phone}'           => isset( $data['phone'] ) ? $data['phone'] : '—',
			'{branch}'          => isset( $data['branch'] ) ? $data['branch'] : '—',
			'{headcount}'       => isset( $data['headcount'] ) ? $data['headcount'] : '1',
			'{total}'           => $total,
			'{due}'             => $due,
			'{paid}'            => $due,
			'{balance}'         => $balance,
			'{plan}'            => isset( $data['plan'] ) ? $data['plan'] : 'full',
			'{plan_label}'      => isset( $data['plan_label'] ) ? $data['plan_label'] : '—',
			'{status}'          => $status,
			'{status_label}'    => EBP_Booking::status_label( $status ),
			'{gateway}'         => $gateway,
			'{gateway_label}'   => $gateway_l,
			'{txn_id}'          => $txn ? $txn : '—',
			'{payment_method}'  => $gateway_l,
			'{package_summary}' => $this->package_summary( $data ),
			'{addon_summary}'   => $this->addon_summary( $data ),
			'{attendees_list}'  => $this->attendees_list( $data ),
			'{admin_url}'       => $this->admin_booking_url( $booking_id ),
		);

		// Ensure a few extra known-safe replacements in admin/payment emails.
		if ( 'payment' === $type ) {
			$placeholder['{paid}'] = $due;
		}

		return $placeholder;
	}

	/**
	 * Format the package summary lines.
	 *
	 * @param array $data Booking data.
	 * @return string
	 */
	private function package_summary( $data ) {
		if ( empty( $data['packages'] ) || ! is_array( $data['packages'] ) ) {
			return __( 'No packages selected.', 'event-booking-pro' );
		}
		$lines = array();
		foreach ( $data['packages'] as $pkg ) {
			$sub = ebp_money( (float) $pkg['price'] * (int) $pkg['qty'] );
			$lines[] = sprintf( '%s x%d - %s', $pkg['name'], $pkg['qty'], $sub );
		}
		if ( ! empty( $data['addons'] ) && is_array( $data['addons'] ) ) {
			foreach ( $data['addons'] as $addon ) {
				$sub = ebp_money( (float) $addon['price'] * (int) $addon['qty'] );
				$lines[] = sprintf( '%s x%d - %s', $addon['name'], $addon['qty'], $sub );
			}
		}
		return $lines ? implode( "\n", $lines ) : __( 'No packages selected.', 'event-booking-pro' );
	}

	/**
	 * Format add-on summary lines.
	 *
	 * @param array $data Booking data.
	 * @return string
	 */
	private function addon_summary( $data ) {
		if ( empty( $data['addons'] ) || ! is_array( $data['addons'] ) ) {
			return __( 'None', 'event-booking-pro' );
		}
		$lines = array();
		foreach ( $data['addons'] as $addon ) {
			$sub = ebp_money( (float) $addon['price'] * (int) $addon['qty'] );
			$lines[] = sprintf( '%s x%d - %s', $addon['name'], $addon['qty'], $sub );
		}
		return $lines ? implode( "\n", $lines ) : __( 'None', 'event-booking-pro' );
	}

	/**
	 * Format the attendee list.
	 *
	 * @param array $data Booking data.
	 * @return string
	 */
	private function attendees_list( $data ) {
		if ( empty( $data['attendees'] ) ) {
			return __( 'None', 'event-booking-pro' );
		}
		$lines = array();
		foreach ( $data['attendees'] as $a ) {
			$name  = ( isset( $a['first'] ) ? $a['first'] : '' ) . ' ' . ( isset( $a['last'] ) ? $a['last'] : '' );
			$age   = isset( $a['age_group'] ) ? $a['age_group'] : '';
			$lines[] = trim( $name . ' (' . $age . ')' );
		}
		return implode( "\n", $lines );
	}

	/**
	 * Admin URL for a booking.
	 *
	 * @param int $booking_id Booking post ID.
	 * @return string
	 */
	private function admin_booking_url( $booking_id ) {
		return $booking_id ? get_edit_post_link( $booking_id, '' ) : home_url();
	}

	/**
	 * From name.
	 *
	 * @return string
	 */
	private function from_name() {
		$name = (string) ebp_settings( 'email.from_name' );
		return $name ? $name : get_bloginfo( 'name' );
	}

	/**
	 * From email.
	 *
	 * @return string
	 */
	private function from_email() {
		$email = (string) ebp_settings( 'email.from_email' );
		if ( ! is_email( $email ) ) {
			$email = get_option( 'admin_email' );
		}
		return $email;
	}

	/**
	 * Wrap plain text body in a simple styled HTML email.
	 *
	 * @param string $body Body text.
	 * @return string
	 */
	private function wrap_html( $body ) {
		$html_body = wp_kses( nl2br( esc_html( $body ) ), array( 'br' => array() ) );
		return '<html><body style="margin:0;padding:0;background:#f4f5f7;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:30px 12px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);">
<tr><td style="background:#0B5FA5;padding:22px 28px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:20px;font-weight:bold;">' . esc_html( get_bloginfo( 'name' ) ) . '</td></tr>
<tr><td style="padding:28px;color:#1B2733;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.7;">' . $html_body . '</td></tr>
<tr><td style="padding:18px 28px;background:#f7f9fb;color:#8494a3;font-family:Arial,Helvetica,sans-serif;font-size:12px;">' . esc_html( get_bloginfo( 'name' ) ) . ' · ' . esc_html( home_url() ) . '</td></tr>
</table>
</td></tr>
</table></body></html>';
	}
}
