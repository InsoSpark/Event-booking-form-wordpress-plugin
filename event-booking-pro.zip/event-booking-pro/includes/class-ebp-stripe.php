<?php
/**
 * Stripe gateway via Payment Intents + Elements (card form embedded on the
 * page). Payment is confirmed synchronously — no webhooks needed.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Stripe extends EBP_Payment {

	const API = 'https://api.stripe.com';

	/**
	 * @var string
	 */
	public $mode;

	/**
	 * @var string
	 */
	public $publishable;

	/**
	 * @var string
	 */
	public $secret;

	/**
	 * Constructor loads credentials from settings.
	 */
	public function __construct() {
		$p                 = ebp_settings( 'payment' );
		$this->mode        = ( isset( $p['stripe_mode'] ) && 'live' === $p['stripe_mode'] ) ? 'live' : 'test';
		$this->publishable = isset( $p['stripe_publishable'] ) ? trim( $p['stripe_publishable'] ) : '';
		$this->secret      = isset( $p['stripe_secret'] ) ? trim( $p['stripe_secret'] ) : '';
	}

	/**
	 * Is this gateway enabled and configured?
	 *
	 * @return bool
	 */
	public function is_configured() {
		$p = ebp_settings( 'payment' );
		return isset( $p['stripe_enabled'] ) && '1' === (string) $p['stripe_enabled'] && '' !== $this->publishable && '' !== $this->secret;
	}

	/**
	 * Create a PaymentIntent for the given booking.
	 *
	 * @param int $booking_id Booking post ID.
	 * @return array|WP_Error { client_secret, id }
	 */
	public function create_intent( $booking_id ) {
		$booking = EBP_Booking::get( $booking_id );
		if ( ! $booking ) {
			return new WP_Error( 'stripe_booking', __( 'Booking not found.', 'event-booking-pro' ) );
		}

		$data     = $booking->data;
		$due      = (float) $data['totals']['due'];
		$currency = strtolower( (string) ebp_settings( 'general.currency_code' ) );
		$cents    = round( $due * 100 );
		$reg_no   = isset( $data['reg_no'] ) ? $data['reg_no'] : '';

		if ( $cents < 50 ) {
			return new WP_Error( 'stripe_amount', __( 'The amount to pay is too small.', 'event-booking-pro' ) );
		}

		$body = array(
			'amount'                => (string) $cents,
			'currency'              => $currency,
			'payment_method_types[]' => 'card',
			'metadata[booking_id]'  => (string) $booking_id,
			'metadata[reg_no]'      => $reg_no,
		);

		$result = $this->remote(
			self::API . '/v1/payment_intents',
			array(
				'method'  => 'POST',
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->secret,
					'Content-Type'  => 'application/x-www-form-urlencoded',
				),
				'body'    => http_build_query( $body ),
			),
			__( 'Stripe intent creation', 'event-booking-pro' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( empty( $result['client_secret'] ) || empty( $result['id'] ) ) {
			return new WP_Error( 'stripe_intent', __( 'Stripe did not return a client secret.', 'event-booking-pro' ) );
		}

		return array(
			'id'            => $result['id'],
			'client_secret' => $result['client_secret'],
		);
	}

	/**
	 * Retrieve a PaymentIntent and check its final status.
	 *
	 * @param string $intent_id PaymentIntent ID.
	 * @return array|WP_Error { status, charge_id }
	 */
	public function retrieve_intent( $intent_id ) {
		$result = $this->remote(
			self::API . '/v1/payment_intents/' . rawurlencode( $intent_id ),
			array(
				'method'  => 'GET',
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->secret,
				),
			),
			__( 'Stripe intent retrieval', 'event-booking-pro' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$status = isset( $result['status'] ) ? $result['status'] : '';
		if ( 'succeeded' !== $status ) {
			return new WP_Error( 'stripe_status', sprintf( __( 'Payment has not succeeded (status: %s).', 'event-booking-pro' ), $status ) );
		}

		$charge_id = isset( $result['charges']['data'][0]['id'] ) ? $result['charges']['data'][0]['id'] : '';

		return array(
			'status'    => $status,
			'charge_id' => $charge_id,
		);
	}
}
