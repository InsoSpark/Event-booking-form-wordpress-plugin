<?php
/**
 * Booking CRUD, pricing engine and status helpers.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Booking {

	const META = '_ebp_data';

	/**
	 * Create a booking from a validated payload. All pricing is recomputed
	 * server-side from the current settings — client totals are never trusted.
	 *
	 * @param array $payload Booking payload.
	 * @return int|WP_Error Booking post ID or error.
	 */
	public static function create( $payload ) {
		$settings = ebp_settings();

		// --- Packages (server priced) -------------------------------------
		$packages = array();
		$total    = 0.0;
		$qty_sum  = 0;

		if ( isset( $payload['packages'] ) && is_array( $payload['packages'] ) ) {
			foreach ( $payload['packages'] as $key => $qty ) {
				$idx = (int) str_replace( 'pkg_', '', $key );
				if ( ! isset( $settings['packages']['packages'][ $idx ] ) ) {
					continue;
				}
				$qty   = (int) $qty;
				$qty   = max( 0, min( 99, $qty ) );
				if ( $qty < 1 ) {
					continue;
				}
				$price = (float) $settings['packages']['packages'][ $idx ]['price'];
				$total += $price * $qty;
				$qty_sum += $qty;
				$packages[] = array(
					'name'  => sanitize_text_field( $settings['packages']['packages'][ $idx ]['name'] ),
					'price' => $price,
					'qty'   => $qty,
				);
			}
		}

		// --- Add-ons (server priced) ---------------------------------------
		$addons = array();
		if ( isset( $payload['addons'] ) && is_array( $payload['addons'] ) ) {
			foreach ( $payload['addons'] as $key => $qty ) {
				$idx = (int) str_replace( 'addon_', '', $key );
				if ( ! isset( $settings['packages']['addons'][ $idx ] ) ) {
					continue;
				}
				$qty   = (int) $qty;
				$qty   = max( 0, min( 99, $qty ) );
				if ( $qty < 1 ) {
					continue;
				}
				$price = (float) $settings['packages']['addons'][ $idx ]['price'];
				$total += $price * $qty;
				$addons[] = array(
					'name'  => sanitize_text_field( $settings['packages']['addons'][ $idx ]['name'] ),
					'price' => $price,
					'qty'   => $qty,
				);
			}
		}

		$total = round( $total, 2 );

		// --- Payment plan ---------------------------------------------------
		$allowed_plans = self::enabled_plans();
		$plan          = isset( $payload['plan'] ) ? sanitize_key( $payload['plan'] ) : 'full';
		if ( ! in_array( $plan, $allowed_plans, true ) ) {
			$plan = $allowed_plans ? $allowed_plans[0] : 'full';
		}
		$plan_label = self::plan_label( $plan );

		$deposit_percent   = (float) ebp_settings( 'payment.deposit_percent' );
		$installment_count = max( 1, (int) ebp_settings( 'payment.installment_count' ) );

		$due = $total;
		if ( 'deposit' === $plan ) {
			$due = round( $total * $deposit_percent / 100, 2 );
		} elseif ( 'installment' === $plan ) {
			$due = round( $total / $installment_count, 2 );
		}
		$balance = max( 0, round( $total - $due, 2 ) );

		// --- Headcount -------------------------------------------------------
		$headcount = $qty_sum;
		if ( $headcount < 1 && ! empty( $payload['attendees'] ) ) {
			$headcount = count( $payload['attendees'] ) + 1;
		}
		if ( $headcount < 1 ) {
			$headcount = 1;
		}

		// --- Basic fields ----------------------------------------------------
		$first = isset( $payload['first_name'] ) ? sanitize_text_field( $payload['first_name'] ) : '';
		$last  = isset( $payload['last_name'] ) ? sanitize_text_field( $payload['last_name'] ) : '';
		$email = isset( $payload['email'] ) ? sanitize_email( $payload['email'] ) : '';

		if ( '' === $first || '' === $last || ! is_email( $email ) ) {
			return new WP_Error( 'ebp_invalid_booking', __( 'Please provide a valid name and email address.', 'event-booking-pro' ) );
		}

		$reg_no = self::generate_reg_no();

		$attendees = array();
		if ( isset( $payload['attendees'] ) && is_array( $payload['attendees'] ) ) {
			foreach ( $payload['attendees'] as $a ) {
				$a = is_array( $a ) ? $a : array();
				$attendees[] = array(
					'first'      => isset( $a['first'] ) ? sanitize_text_field( $a['first'] ) : '',
					'last'       => isset( $a['last'] ) ? sanitize_text_field( $a['last'] ) : '',
					'age_group'  => isset( $a['age_group'] ) ? sanitize_text_field( $a['age_group'] ) : '',
					'shirt_size' => isset( $a['shirt_size'] ) ? sanitize_text_field( $a['shirt_size'] ) : '',
					'meal'       => isset( $a['meal'] ) ? sanitize_text_field( $a['meal'] ) : '',
					'access'     => isset( $a['access'] ) ? sanitize_text_field( $a['access'] ) : '',
					'relation'   => isset( $a['relation'] ) ? sanitize_text_field( $a['relation'] ) : '',
				);
			}
		}

		$data = array(
			'reg_no'      => $reg_no,
			'first_name'  => $first,
			'last_name'   => $last,
			'email'       => $email,
			'phone'       => isset( $payload['phone'] ) ? sanitize_text_field( $payload['phone'] ) : '',
			'branch'      => isset( $payload['branch'] ) ? sanitize_text_field( $payload['branch'] ) : '',
			'address'     => isset( $payload['address'] ) ? sanitize_text_field( $payload['address'] ) : '',
			'attendees'   => $attendees,
			'packages'    => $packages,
			'addons'      => $addons,
			'headcount'   => $headcount,
			'plan'        => $plan,
			'plan_label'  => $plan_label,
			'totals'      => array(
				'total'             => $total,
				'due'               => $due,
				'balance'           => $balance,
				'deposit_percent'   => $deposit_percent,
				'installment_count' => $installment_count,
			),
			'payment'     => array(
				'gateway'       => '',
				'status'        => 'pending',
				'transaction_id'=> '',
				'amount'        => 0,
				'currency'      => (string) ebp_settings( 'general.currency_code' ),
				'paid_date'     => '',
			),
			'status'      => 'pending',
			'created'     => current_time( 'mysql' ),
		);

		$post_id = wp_insert_post(
			array(
				'post_type'   => EBP_CPT,
				'post_status' => 'publish',
				'post_title'  => $reg_no . ' — ' . $first . ' ' . $last,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		update_post_meta( $post_id, self::META, $data );
		update_post_meta( $post_id, '_ebp_status', 'pending' );
		update_post_meta( $post_id, '_ebp_reg_no', $reg_no );

		return $post_id;
	}

	/**
	 * Get the booking data array.
	 *
	 * @param int $booking_id Booking post ID.
	 * @return array
	 */
	public static function get_data( $booking_id ) {
		$data = get_post_meta( $booking_id, self::META, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Get a full booking (post + data).
	 *
	 * @param int $booking_id Booking post ID.
	 * @return object|null
	 */
	public static function get( $booking_id ) {
		$post = get_post( (int) $booking_id );
		if ( ! $post || EBP_CPT !== $post->post_type ) {
			return null;
		}
		return (object) array(
			'id'   => $post->ID,
			'post' => $post,
			'data' => self::get_data( $post->ID ),
		);
	}

	/**
	 * Get the current status of a booking.
	 *
	 * @param int $booking_id Booking post ID.
	 * @return string
	 */
	public static function get_status( $booking_id ) {
		$status = get_post_meta( $booking_id, '_ebp_status', true );
		return $status ? $status : 'pending';
	}

	/**
	 * Update booking status.
	 *
	 * @param int    $booking_id Booking post ID.
	 * @param string $status     New status.
	 */
	public static function update_status( $booking_id, $status ) {
		$status = array_key_exists( $status, self::status_options() ) ? $status : 'pending';
		update_post_meta( $booking_id, '_ebp_status', $status );
		$data = self::get_data( $booking_id );
		if ( $data ) {
			$data['status']            = $status;
			$data['payment']['status'] = $status;
			update_post_meta( $booking_id, self::META, $data );
		}
	}

	/**
	 * Mark a booking as paid after a successful gateway capture/confirmation.
	 *
	 * @param int    $booking_id     Booking post ID.
	 * @param string $gateway        Gateway slug (paypal|stripe).
	 * @param string $transaction_id Transaction ID.
	 * @param float  $amount         Paid amount.
	 * @param string $currency       Currency code.
	 */
	public static function mark_paid( $booking_id, $gateway, $transaction_id, $amount, $currency ) {
		update_post_meta( $booking_id, '_ebp_status', 'paid' );
		$data = self::get_data( $booking_id );
		if ( $data ) {
			$data['status'] = 'paid';
			$data['payment'] = array(
				'gateway'        => $gateway,
				'status'         => 'paid',
				'transaction_id' => $transaction_id,
				'amount'         => (float) $amount,
				'currency'       => $currency,
				'paid_date'      => current_time( 'mysql' ),
			);
			update_post_meta( $booking_id, self::META, $data );
		}
	}

	/**
	 * Generate a unique registration number.
	 *
	 * @return string
	 */
	public static function generate_reg_no() {
		$prefix = preg_replace( '/[^A-Z0-9\-]/i', '', (string) ebp_settings( 'general.reg_prefix' ) );
		$prefix = $prefix ? $prefix : 'EBP';
		$prefix = strtoupper( $prefix );

		for ( $i = 0; $i < 50; $i++ ) {
			$reg = $prefix . '-' . wp_rand( 100000, 999999 );
			$found = get_posts(
				array(
					'post_type'  => EBP_CPT,
					'meta_key'   => '_ebp_reg_no',
					'meta_value' => $reg,
					'fields'     => 'ids',
					'numberposts' => 1,
				)
			);
			if ( empty( $found ) ) {
				return $reg;
			}
		}
		return $prefix . '-' . time();
	}

	/**
	 * Which payment plans are enabled in settings.
	 *
	 * @return array
	 */
	public static function enabled_plans() {
		$p    = ebp_settings( 'payment' );
		$plans = array();
		foreach ( array( 'plan_full', 'plan_deposit', 'plan_installment' ) as $key ) {
			if ( isset( $p[ $key ] ) && '1' === (string) $p[ $key ] ) {
				$plans[] = str_replace( 'plan_', '', $key );
			}
		}
		return $plans ? $plans : array( 'full' );
	}

	/**
	 * Human label for a plan slug.
	 *
	 * @param string $plan Plan slug.
	 * @return string
	 */
	public static function plan_label( $plan ) {
		switch ( $plan ) {
			case 'deposit':
				return __( 'Deposit', 'event-booking-pro' );
			case 'installment':
				return __( 'Installment Plan', 'event-booking-pro' );
			default:
				return __( 'Paid in Full', 'event-booking-pro' );
		}
	}

	/**
	 * Status options (slug => label).
	 *
	 * @return array
	 */
	public static function status_options() {
		return array(
			'pending'   => __( 'Pending', 'event-booking-pro' ),
			'paid'      => __( 'Paid', 'event-booking-pro' ),
			'refunded'  => __( 'Refunded', 'event-booking-pro' ),
			'cancelled' => __( 'Cancelled', 'event-booking-pro' ),
		);
	}

	/**
	 * Label for a status slug.
	 *
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function status_label( $status ) {
		$options = self::status_options();
		return isset( $options[ $status ] ) ? $options[ $status ] : $status;
	}
}
