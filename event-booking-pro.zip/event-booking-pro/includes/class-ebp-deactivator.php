<?php
/**
 * Deactivation routines.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Deactivator {

	/**
	 * Run on plugin deactivation.
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}
}
