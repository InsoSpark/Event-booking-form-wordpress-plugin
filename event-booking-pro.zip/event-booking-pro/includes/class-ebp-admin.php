<?php
/**
 * General admin wiring (notices, etc.).
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Admin {

	/**
	 * Hook everything up.
	 */
	public function __construct() {
		add_action( 'admin_notices', array( $this, 'activation_notice' ) );
	}

	/**
	 * Show a one-time setup notice pointing to the settings page.
	 */
	public function activation_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( 'yes' === get_option( 'ebp_notice_dismissed' ) ) {
			return;
		}
		if ( isset( $_GET['ebp_notice'] ) && 'dismiss' === sanitize_key( wp_unslash( $_GET['ebp_notice'] ) ) ) {
			update_option( 'ebp_notice_dismissed', 'yes' );
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$hook   = $screen ? $screen->id : '';
		if ( false !== strpos( $hook, 'ebp' ) ) {
			return;
		}
		?>
		<div class="notice notice-info is-dismissible">
			<p>
				<strong><?php esc_html_e( 'Event Booking Pro', 'event-booking-pro' ); ?></strong> —
				<?php esc_html_e( 'Add', 'event-booking-pro' ); ?>
				<code>[event_booking_pro]</code>
				<?php esc_html_e( 'to any page to show the booking form, then', 'event-booking-pro' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ebp-settings' ) ); ?>"><?php esc_html_e( 'configure your event here', 'event-booking-pro' ); ?></a>.
			</p>
		</div>
		<?php
	}
}
