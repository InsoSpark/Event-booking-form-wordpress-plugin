<?php
/**
 * Loader: wires every component together and provides global helpers.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

require_once EBP_PLUGIN_DIR . 'includes/class-ebp-settings-defaults.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-post-types.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-booking.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-payment.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-paypal.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-stripe.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-emails.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-settings.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-admin.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-frontend.php';
require_once EBP_PLUGIN_DIR . 'includes/class-ebp-ajax.php';

/**
 * Read plugin settings. Accepts a dotted path, e.g. ebp_settings( 'payment.paypal_enabled' ).
 *
 * @param string|null $path Dotted path to a setting (e.g. "general.event_name").
 * @return mixed
 */
function ebp_settings( $path = null ) {
	static $settings = false;

	if ( false === $settings ) {
		$defaults = EBP_Settings_Defaults::get();
		$saved    = get_option( 'ebp_settings', array() );
		$settings = array_replace_recursive( $defaults, is_array( $saved ) ? $saved : array() );
	}

	if ( null === $path ) {
		return $settings;
	}

	$keys = explode( '.', $path );
	$val  = $settings;
	foreach ( $keys as $key ) {
		if ( ! isset( $val[ $key ] ) ) {
			return null;
		}
		$val = $val[ $key ];
	}

	return $val;
}

/**
 * Return the configured currency symbol.
 *
 * @return string
 */
function ebp_currency_symbol() {
	$sym = (string) ebp_settings( 'general.currency_symbol' );
	if ( '' !== $sym ) {
		return $sym;
	}
	$code    = strtoupper( (string) ebp_settings( 'general.currency_code' ) );
	$symbols = array(
		'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'INR' => '₹', 'BDT' => '৳',
		'CAD' => 'C$', 'AUD' => 'A$', 'JPY' => '¥', 'CHF' => 'CHF', 'NZD' => 'NZ$',
	);
	return isset( $symbols[ $code ] ) ? $symbols[ $code ] : '$';
}

/**
 * Format a money amount using the configured currency.
 *
 * @param float $amount Amount.
 * @return string
 */
function ebp_money( $amount ) {
	$code   = strtoupper( (string) ebp_settings( 'general.currency_code' ) );
	$dec    = in_array( $code, array( 'JPY', 'KRW', 'VND', 'IDR' ), true ) ? 0 : 2;
	return ebp_currency_symbol() . number_format( (float) $amount, $dec );
}

class EBP_Loader {

	/**
	 * Singleton instance.
	 *
	 * @var EBP_Loader|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton.
	 *
	 * @return EBP_Loader
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Instantiate all components.
	 */
	private function __construct() {
		new EBP_Post_Types();
		new EBP_Booking();
		new EBP_Emails();
		new EBP_Settings();
		new EBP_Admin();
		new EBP_Frontend();
		new EBP_Ajax();
	}
}
