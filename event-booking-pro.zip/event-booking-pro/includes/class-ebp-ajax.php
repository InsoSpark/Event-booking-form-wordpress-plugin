<?php
/**
 * All AJAX handlers: booking creation, gateway calls, admin actions.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Ajax {

	/**
	 * Hook everything up.
	 */
	public function __construct() {
		add_action( 'wp_ajax_ebp_create_booking', array( $this, 'create_booking' ) );
		add_action( 'wp_ajax_nopriv_ebp_create_booking', array( $this, 'create_booking' ) );

		add_action( 'wp_ajax_ebp_stripe_intent', array( $this, 'stripe_intent' ) );
		add_action( 'wp_ajax_nopriv_ebp_stripe_intent', array( $this, 'stripe_intent' ) );
		add_action( 'wp_ajax_ebp_stripe_confirm', array( $this, 'stripe_confirm' ) );
		add_action( 'wp_ajax_nopriv_ebp_stripe_confirm', array( $this, 'stripe_confirm' ) );

		add_action( 'wp_ajax_ebp_paypal_create_order', array( $this, 'paypal_create_order' ) );
		add_action( 'wp_ajax_nopriv_ebp_paypal_create_order', array( $this, 'paypal_create_order' ) );
		add_action( 'wp_ajax_ebp_paypal_capture', array( $this, 'paypal_capture' ) );
		add_action( 'wp_ajax_nopriv_ebp_paypal_capture', array( $this, 'paypal_capture' ) );

		add_action( 'wp_ajax_ebp_admin_update_booking', array( $this, 'admin_update_booking' ) );
		add_action( 'wp_ajax_ebp_admin_resend_email', array( $this, 'admin_resend_email' ) );
	}

	/**
	 * Verify the public nonce and return an error if it fails.
	 */
	private function verify_public() {
		if ( ! check_ajax_referer( 'ebp_public', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'event-booking-pro' ) ), 403 );
		}
	}

	/**
	 * Verify admin capability + nonce.
	 */
	private function verify_admin() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'ebp_admin', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'event-booking-pro' ) ), 403 );
		}
	}

	/**
	 * Create a booking from the front-end form.
	 */
	public function create_booking() {
		$this->verify_public();

		$payload = array(
			'first_name' => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
			'last_name'  => isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '',
			'email'      => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
			'phone'      => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
			'branch'     => isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '',
			'address'    => isset( $_POST['address'] ) ? sanitize_text_field( wp_unslash( $_POST['address'] ) ) : '',
			'plan'       => isset( $_POST['plan'] ) ? sanitize_key( wp_unslash( $_POST['plan'] ) ) : 'full',
			'packages'   => isset( $_POST['packages'] ) ? $this->clean_qty_map( json_decode( wp_unslash( $_POST['packages'] ), true ) ) : array(),
			'addons'     => isset( $_POST['addons'] ) ? $this->clean_qty_map( json_decode( wp_unslash( $_POST['addons'] ), true ) ) : array(),
			'attendees'  => isset( $_POST['attendees'] ) ? $this->clean_attendees( json_decode( wp_unslash( $_POST['attendees'] ), true ) ) : array(),
		);

		$booking_id = EBP_Booking::create( $payload );
		if ( is_wp_error( $booking_id ) ) {
			wp_send_json_error( array( 'message' => $booking_id->get_error_message() ) );
		}

		$data = EBP_Booking::get_data( $booking_id );

		// If there is nothing to pay, finalize immediately.
		if ( (float) $data['totals']['due'] <= 0 ) {
			EBP_Booking::mark_paid( $booking_id, 'free', 'FREE-' . time(), 0, (string) ebp_settings( 'general.currency_code' ) );
			$emails = new EBP_Emails();
			$emails->send_payment_received( $booking_id );
			$emails->send_admin_notification( $booking_id, 'new' );
			$data = EBP_Booking::get_data( $booking_id );
		} else {
			$emails = new EBP_Emails();
			$emails->send_confirmation( $booking_id );
			$emails->send_admin_notification( $booking_id, 'new' );
		}

		wp_send_json_success( $this->booking_response( $data, $booking_id ) );
	}

	/**
	 * Create a Stripe PaymentIntent for a booking.
	 */
	public function stripe_intent() {
		$this->verify_public();
		$booking_id = isset( $_POST['booking_id'] ) ? (int) $_POST['booking_id'] : 0;
		$booking    = EBP_Booking::get( $booking_id );
		if ( ! $booking ) {
			wp_send_json_error( array( 'message' => __( 'Booking not found.', 'event-booking-pro' ) ) );
		}

		$stripe = new EBP_Stripe();
		if ( ! $stripe->is_configured() ) {
			wp_send_json_error( array( 'message' => __( 'Stripe is not configured. Please contact the site administrator.', 'event-booking-pro' ) ) );
		}

		$intent = $stripe->create_intent( $booking_id );
		if ( is_wp_error( $intent ) ) {
			wp_send_json_error( array( 'message' => $intent->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'intent_id'     => $intent['id'],
				'client_secret' => $intent['client_secret'],
			)
		);
	}

	/**
	 * Confirm a Stripe payment server-side and mark the booking paid.
	 */
	public function stripe_confirm() {
		$this->verify_public();
		$booking_id = isset( $_POST['booking_id'] ) ? (int) $_POST['booking_id'] : 0;
		$intent_id  = isset( $_POST['intent_id'] ) ? sanitize_text_field( wp_unslash( $_POST['intent_id'] ) ) : '';

		if ( ! $booking_id || ! $intent_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing payment details.', 'event-booking-pro' ) ) );
		}

		$stripe = new EBP_Stripe();
		$result = $stripe->retrieve_intent( $intent_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$data     = EBP_Booking::get_data( $booking_id );
		$currency = (string) ebp_settings( 'general.currency_code' );
		EBP_Booking::mark_paid( $booking_id, 'stripe', $result['charge_id'], (float) $data['totals']['due'], $currency );

		$emails = new EBP_Emails();
		$emails->send_payment_received( $booking_id );

		$data = EBP_Booking::get_data( $booking_id );
		wp_send_json_success( $this->booking_response( $data, $booking_id ) );
	}

	/**
	 * Create a PayPal order for a booking.
	 */
	public function paypal_create_order() {
		$this->verify_public();
		$booking_id = isset( $_POST['booking_id'] ) ? (int) $_POST['booking_id'] : 0;
		$booking    = EBP_Booking::get( $booking_id );
		if ( ! $booking ) {
			wp_send_json_error( array( 'message' => __( 'Booking not found.', 'event-booking-pro' ) ) );
		}

		$paypal = new EBP_PayPal();
		if ( ! $paypal->is_configured() ) {
			wp_send_json_error( array( 'message' => __( 'PayPal is not configured. Please contact the site administrator.', 'event-booking-pro' ) ) );
		}

		$order = $paypal->create_order( $booking_id );
		if ( is_wp_error( $order ) ) {
			wp_send_json_error( array( 'message' => $order->get_error_message() ) );
		}

		wp_send_json_success( array( 'order_id' => $order['id'] ) );
	}

	/**
	 * Capture an approved PayPal order and mark the booking paid.
	 */
	public function paypal_capture() {
		$this->verify_public();
		$booking_id = isset( $_POST['booking_id'] ) ? (int) $_POST['booking_id'] : 0;
		$order_id   = isset( $_POST['order_id'] ) ? sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) : '';

		if ( ! $booking_id || ! $order_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing payment details.', 'event-booking-pro' ) ) );
		}

		$paypal = new EBP_PayPal();
		$result = $paypal->capture_order( $order_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$data     = EBP_Booking::get_data( $booking_id );
		$currency = (string) ebp_settings( 'general.currency_code' );
		EBP_Booking::mark_paid( $booking_id, 'paypal', $result['capture_id'], (float) $data['totals']['due'], $currency );

		$emails = new EBP_Emails();
		$emails->send_payment_received( $booking_id );

		$data = EBP_Booking::get_data( $booking_id );
		wp_send_json_success( $this->booking_response( $data, $booking_id ) );
	}

	/**
	 * Admin: update booking status.
	 */
	public function admin_update_booking() {
		$this->verify_admin();
		$booking_id = isset( $_POST['booking_id'] ) ? (int) $_POST['booking_id'] : 0;
		$status     = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';

		if ( ! $booking_id || ! array_key_exists( $status, EBP_Booking::status_options() ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', 'event-booking-pro' ) ) );
		}

		EBP_Booking::update_status( $booking_id, $status );
		wp_send_json_success( array( 'status' => $status, 'label' => EBP_Booking::status_label( $status ) ) );
	}

	/**
	 * Admin: resend an email for a booking.
	 */
	public function admin_resend_email() {
		$this->verify_admin();
		$booking_id = isset( $_POST['booking_id'] ) ? (int) $_POST['booking_id'] : 0;
		$type       = isset( $_POST['email_type'] ) ? sanitize_key( wp_unslash( $_POST['email_type'] ) ) : '';

		if ( ! $booking_id || ! in_array( $type, array( 'confirmation', 'payment', 'admin' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', 'event-booking-pro' ) ) );
		}

		$emails = new EBP_Emails();
		if ( 'admin' === $type ) {
			$sent = $emails->send_admin_notification( $booking_id, 'new' );
		} else {
			$sent = $emails->send( $booking_id, $type );
		}

		if ( $sent ) {
			wp_send_json_success( array( 'message' => __( 'Email sent.', 'event-booking-pro' ) ) );
		}
		wp_send_json_error( array( 'message' => __( 'Email could not be sent. Check your mail settings.', 'event-booking-pro' ) ) );
	}

	/**
	 * Build the standardized booking response for the front-end.
	 *
	 * @param array $data       Booking data.
	 * @param int   $booking_id Booking post ID.
	 * @return array
	 */
	private function booking_response( $data, $booking_id ) {
		$total   = (float) $data['totals']['total'];
		$due     = (float) $data['totals']['due'];
		$balance = (float) $data['totals']['balance'];
		$status  = EBP_Booking::get_status( $booking_id );

		$gateways = array();
		$paypal   = new EBP_PayPal();
		$stripe   = new EBP_Stripe();
		if ( $paypal->is_configured() ) {
			$gateways[] = 'paypal';
		}
		if ( $stripe->is_configured() ) {
			$gateways[] = 'stripe';
		}

		return array(
			'booking_id'   => (int) $booking_id,
			'reg_no'       => $data['reg_no'],
			'total'        => $total,
			'due'          => $due,
			'balance'      => $balance,
			'total_fmt'    => ebp_money( $total ),
			'due_fmt'      => ebp_money( $due ),
			'balance_fmt'  => ebp_money( $balance ),
			'currency'     => (string) ebp_settings( 'general.currency_code' ),
			'plan'         => $data['plan'],
			'plan_label'   => $data['plan_label'],
			'status'       => $status,
			'needs_payment'=> $due > 0 && 'paid' !== $status,
			'gateways'     => $gateways,
			'name'         => ( isset( $data['first_name'] ) ? $data['first_name'] : '' ) . ' ' . ( isset( $data['last_name'] ) ? $data['last_name'] : '' ),
			'headcount'    => $data['headcount'],
		);
	}

	/**
	 * Sanitize a package/addon qty map like { "pkg_0": "2", "addon_1": "1" }.
	 *
	 * @param mixed $map Raw map.
	 * @return array
	 */
	private function clean_qty_map( $map ) {
		$clean = array();
		if ( ! is_array( $map ) ) {
			return $clean;
		}
		foreach ( $map as $key => $qty ) {
			$key = sanitize_key( $key );
			$qty = max( 0, min( 99, (int) $qty ) );
			if ( $qty > 0 ) {
				$clean[ $key ] = $qty;
			}
		}
		return $clean;
	}

	/**
	 * Sanitize the attendee array.
	 *
	 * @param mixed $attendees Raw attendees.
	 * @return array
	 */
	private function clean_attendees( $attendees ) {
		$clean = array();
		if ( ! is_array( $attendees ) ) {
			return $clean;
		}
		foreach ( $attendees as $a ) {
			if ( ! is_array( $a ) ) {
				continue;
			}
			$clean[] = array(
				'first'      => isset( $a['first'] ) ? sanitize_text_field( $a['first'] ) : '',
				'last'       => isset( $a['last'] ) ? sanitize_text_field( $a['last'] ) : '',
				'age_group'  => isset( $a['age_group'] ) ? sanitize_text_field( $a['age_group'] ) : '',
				'shirt_size' => isset( $a['shirt_size'] ) ? sanitize_text_field( $a['shirt_size'] ) : '',
				'meal'       => isset( $a['meal'] ) ? sanitize_text_field( $a['meal'] ) : '',
				'access'     => isset( $a['access'] ) ? sanitize_text_field( $a['access'] ) : '',
				'relation'   => isset( $a['relation'] ) ? sanitize_text_field( $a['relation'] ) : '',
			);
		}
		return $clean;
	}
}
