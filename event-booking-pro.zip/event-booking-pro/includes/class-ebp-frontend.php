<?php
/**
 * Front-end: shortcode, asset loading and config localization.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Frontend {

	/**
	 * Whether assets were already printed on this page.
	 *
	 * @var bool
	 */
	private $printed = false;

	/**
	 * Hook everything up.
	 */
	public function __construct() {
		add_shortcode( 'event_booking_pro', array( $this, 'shortcode' ) );
		add_shortcode( 'event_booking', array( $this, 'shortcode' ) );
		add_action( 'wp_footer', array( $this, 'print_custom_css' ), 99 );
	}

	/**
	 * Render the booking form.
	 *
	 * @return string
	 */
	public function shortcode() {
		if ( ! $this->printed ) {
			$this->enqueue_assets();
			$this->printed = true;
		}

		ob_start();
		$settings  = ebp_settings();
		$packages  = $settings['packages']['packages'];
		$addons    = $settings['packages']['addons'];
		$plans     = EBP_Booking::enabled_plans();
		$paypal    = new EBP_PayPal();
		$stripe    = new EBP_Stripe();
		$gateways  = array();
		if ( $paypal->is_configured() ) {
			$gateways['paypal'] = $paypal;
		}
		if ( $stripe->is_configured() ) {
			$gateways['stripe'] = $stripe;
		}

		$app = $settings['appearance'];
		$style = sprintf(
			'--ebp-primary:%s;--ebp-accent:%s;--ebp-bg:%s;--ebp-btn:%s;',
			esc_html( $app['primary_color'] ),
			esc_html( $app['accent_color'] ),
			esc_html( $app['background_color'] ),
			esc_html( $app['button_color'] )
		);

		include EBP_PLUGIN_DIR . 'templates/booking-form.php';
		return ob_get_clean();
	}

	/**
	 * Enqueue front-end assets.
	 */
	private function enqueue_assets() {
		wp_enqueue_style( 'ebp-frontend', EBP_PLUGIN_URL . 'assets/css/frontend.css', array(), EBP_VERSION );
		wp_enqueue_script( 'ebp-frontend', EBP_PLUGIN_URL . 'assets/js/frontend.js', array(), EBP_VERSION, true );

		$appearance = ebp_settings( 'appearance' );
		if ( 'montserrat' === $appearance['font_family'] ) {
			wp_enqueue_style( 'ebp-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Montserrat:wght@400;500;600;700&family=Great+Vibes&display=swap', array(), null );
		} elseif ( 'lora' === $appearance['font_family'] ) {
			wp_enqueue_style( 'ebp-fonts', 'https://fonts.googleapis.com/css2?family=Lora:wght@500;600&family=Poppins:wght@400;500;600&display=swap', array(), null );
		}

		$paypal = new EBP_PayPal();
		$stripe = new EBP_Stripe();
		if ( $stripe->is_configured() ) {
			wp_enqueue_script( 'stripe-js', 'https://js.stripe.com/v3/', array(), null, true );
		}
		if ( $paypal->is_configured() ) {
			wp_enqueue_script( 'paypal-sdk', $paypal->sdk_url(), array(), null, true );
		}

		$settings = ebp_settings();
		wp_localize_script(
			'ebp-frontend',
			'EBP',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ebp_public' ),
				'packages' => $settings['packages']['packages'],
				'addons'   => $settings['packages']['addons'],
				'plans'    => array(
					'full'          => in_array( 'full', EBP_Booking::enabled_plans(), true ),
					'deposit'       => in_array( 'deposit', EBP_Booking::enabled_plans(), true ),
					'installment'   => in_array( 'installment', EBP_Booking::enabled_plans(), true ),
					'deposit_percent'   => (float) $settings['payment']['deposit_percent'],
					'installment_count' => (int) $settings['payment']['installment_count'],
				),
				'gateways' => array(
					'paypal' => array(
						'enabled' => $paypal->is_configured(),
						'label'   => __( 'PayPal', 'event-booking-pro' ),
					),
					'stripe' => array(
						'enabled'    => $stripe->is_configured(),
						'label'      => __( 'Credit / Debit Card', 'event-booking-pro' ),
						'publishable'=> $stripe->publishable,
					),
				),
				'currency' => array(
					'code'   => (string) $settings['general']['currency_code'],
					'symbol' => ebp_currency_symbol(),
				),
				'ageGroups' => array( 'Adult 18-64', 'Teen 13-17', 'Child 4-12', 'Toddler 0-3', 'Senior 65+' ),
				'shirtSizes' => array( 'YS', 'YM', 'YL', 'S', 'M', 'L', 'XL', '2XL' ),
				'config' => array(
					'show_hotel_btn' => '1' === (string) $settings['appearance']['show_hotel_btn'],
					'hotel_url'      => $settings['appearance']['hotel_url'],
					'confirm_message'=> $settings['general']['confirm_message'],
				),
				'i18n' => array(
					'error'       => __( 'Something went wrong. Please try again.', 'event-booking-pro' ),
					'processing'  => __( 'Processing…', 'event-booking-pro' ),
					'payNow'      => __( 'Pay', 'event-booking-pro' ),
					'noGateway'   => __( 'No payment gateway is configured. Please contact the site administrator.', 'event-booking-pro' ),
					'fillRequired'=> __( 'Please fill in your name and a valid email address to continue.', 'event-booking-pro' ),
					'selectGateway'=> __( 'Please select a payment method.', 'event-booking-pro' ),
					'cardError'   => __( 'Please check your card details.', 'event-booking-pro' ),
				),
			)
		);
	}

	/**
	 * Print any custom CSS in the footer (only when the form was rendered).
	 */
	public function print_custom_css() {
		if ( ! $this->printed ) {
			return;
		}
		$css = (string) ebp_settings( 'appearance.custom_css' );
		if ( '' !== $css ) {
			echo '<style id="ebp-custom-css">' . wp_strip_all_tags( $css ) . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
