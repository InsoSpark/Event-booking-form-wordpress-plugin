<?php
/**
 * Activation routines.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Activator {

	/**
	 * Run on plugin activation.
	 */
	public static function activate() {
		require_once EBP_PLUGIN_DIR . 'includes/class-ebp-settings-defaults.php';

		$defaults = EBP_Settings_Defaults::get();
		$current  = get_option( 'ebp_settings', null );

		if ( null === $current || ! is_array( $current ) ) {
			add_option( 'ebp_settings', $defaults );
		} else {
			update_option( 'ebp_settings', array_replace_recursive( $defaults, $current ) );
		}

		update_option( 'ebp_version', EBP_VERSION );

		// Register the CPT so rewrite rules know about it, then flush.
		if ( ! post_type_exists( EBP_CPT ) ) {
			require_once EBP_PLUGIN_DIR . 'includes/class-ebp-post-types.php';
			$pt = new EBP_Post_Types();
			$pt->register();
		}

		flush_rewrite_rules();
	}
}
