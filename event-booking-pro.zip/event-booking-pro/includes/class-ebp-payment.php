<?php
/**
 * Payment base class + factory helpers.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

abstract class EBP_Payment {

	/**
	 * Perform a remote request with shared error handling.
	 *
	 * @param string $url  Request URL.
	 * @param array  $args Request arguments.
	 * @param string $what Human label for the operation.
	 * @return array|WP_Error Decoded JSON body or WP_Error.
	 */
	protected function remote( $url, $args, $what = 'request' ) {
		$args['timeout'] = 30;

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			$data = array( 'raw' => $body );
		}

		if ( $code < 200 || $code >= 300 ) {
			$message = isset( $data['message'] ) ? $data['message'] : '';
			if ( isset( $data['error']['message'] ) ) {
				$message = $data['error']['message'];
			}
			if ( isset( $data['error_description'] ) ) {
				$message = $data['error_description'];
			}
			$this->log( sprintf( '%s failed (HTTP %s): %s', $what, $code, wp_json_encode( $data ) ) );
			return new WP_Error( 'ebp_remote', sprintf( __( '%s failed: %s', 'event-booking-pro' ), $what, $message ? $message : 'Unknown error' ) );
		}

		return $data;
	}

	/**
	 * Write a debug line to the error log.
	 *
	 * @param string $message Message.
	 */
	protected function log( $message ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( '[Event Booking Pro] ' . $message );
	}
}
