<?php
/**
 * PayPal REST v2 gateway. Uses Client ID + Secret only — no webhooks needed.
 * Payment is captured synchronously on the approval return.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_PayPal extends EBP_Payment {

	const LIVE    = 'https://api-m.paypal.com';
	const SANDBOX = 'https://api-m.sandbox.paypal.com';

	/**
	 * @var string
	 */
	public $mode;

	/**
	 * @var string
	 */
	public $client_id;

	/**
	 * @var string
	 */
	public $secret;

	/**
	 * Constructor loads credentials from settings.
	 */
	public function __construct() {
		$p         = ebp_settings( 'payment' );
		$this->mode      = ( isset( $p['paypal_mode'] ) && 'live' === $p['paypal_mode'] ) ? 'live' : 'sandbox';
		$this->client_id = isset( $p['paypal_client_id'] ) ? trim( $p['paypal_client_id'] ) : '';
		$this->secret    = isset( $p['paypal_secret'] ) ? trim( $p['paypal_secret'] ) : '';
	}

	/**
	 * Is this gateway enabled and configured?
	 *
	 * @return bool
	 */
	public function is_configured() {
		$p = ebp_settings( 'payment' );
		return isset( $p['paypal_enabled'] ) && '1' === (string) $p['paypal_enabled'] && '' !== $this->client_id && '' !== $this->secret;
	}

	/**
	 * Base API url for the current mode.
	 *
	 * @return string
	 */
	public function base() {
		return 'live' === $this->mode ? self::LIVE : self::SANDBOX;
	}

	/**
	 * SDK url (client-side) for the current mode.
	 *
	 * @return string
	 */
	public function sdk_url() {
		$currency = strtoupper( (string) ebp_settings( 'general.currency_code' ) );
		$host     = 'live' === $this->mode ? 'www.paypal.com' : 'www.sandbox.paypal.com';
		return 'https://' . $host . '/sdk/js?client-id=' . rawurlencode( $this->client_id ) . '&currency=' . rawurlencode( $currency ) . '&intent=capture&enable-funding=card';
	}

	/**
	 * Exchange client ID + secret for an access token.
	 *
	 * @return string|WP_Error
	 */
	public function get_access_token() {
		$result = $this->remote(
			$this->base() . '/v1/oauth2/token',
			array(
				'method'  => 'POST',
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode( $this->client_id . ':' . $this->secret ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
					'Content-Type'  => 'application/x-www-form-urlencoded',
				),
				'body'    => 'grant_type=client_credentials',
			),
			__( 'PayPal token request', 'event-booking-pro' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! isset( $result['access_token'] ) ) {
			return new WP_Error( 'paypal_token', __( 'PayPal could not provide an access token. Check your Client ID and Secret.', 'event-booking-pro' ) );
		}

		return $result['access_token'];
	}

	/**
	 * Create a PayPal order for the given booking.
	 *
	 * @param int $booking_id Booking post ID.
	 * @return array|WP_Error { id: ..., links: [...] }
	 */
	public function create_order( $booking_id ) {
		$booking = EBP_Booking::get( $booking_id );
		if ( ! $booking ) {
			return new WP_Error( 'paypal_booking', __( 'Booking not found.', 'event-booking-pro' ) );
		}

		$data   = $booking->data;
		$due    = (float) $data['totals']['due'];
		$name   = ( isset( $data['first_name'] ) ? $data['first_name'] : '' ) . ' ' . ( isset( $data['last_name'] ) ? $data['last_name'] : '' );
		$reg_no = isset( $data['reg_no'] ) ? $data['reg_no'] : '';
		$currency = strtoupper( (string) ebp_settings( 'general.currency_code' ) );

		$token = $this->get_access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$body = array(
			'intent' => 'CAPTURE',
			'purchase_units' => array(
				array(
					'reference_id' => (string) $booking_id,
					'description'  => substr( sprintf( 'Booking %s - %s', $reg_no, $name ), 0, 120 ),
					'amount'       => array(
						'currency_code' => $currency,
						'value'         => number_format( $due, 2, '.', '' ),
					),
				),
			),
			'application_context' => array(
				'shipping_preference' => 'NO_SHIPPING',
				'user_action'         => 'PAY_NOW',
				'return_url'          => home_url( '/' ),
				'cancel_url'          => home_url( '/' ),
			),
		);

		$result = $this->remote(
			$this->base() . '/v2/checkout/orders',
			array(
				'method'  => 'POST',
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			),
			__( 'PayPal order creation', 'event-booking-pro' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( empty( $result['id'] ) ) {
			return new WP_Error( 'paypal_order', __( 'PayPal did not return an order ID.', 'event-booking-pro' ) );
		}

		return array( 'id' => $result['id'] );
	}

	/**
	 * Capture an approved PayPal order immediately (no webhook needed).
	 *
	 * @param string $order_id PayPal order ID.
	 * @return array|WP_Error { id: capture id }
	 */
	public function capture_order( $order_id ) {
		$token = $this->get_access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$result = $this->remote(
			$this->base() . '/v2/checkout/orders/' . rawurlencode( $order_id ) . '/capture',
			array(
				'method'  => 'POST',
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				),
			),
			__( 'PayPal capture', 'event-booking-pro' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$status = isset( $result['status'] ) ? $result['status'] : '';
		if ( 'COMPLETED' !== $status ) {
			return new WP_Error( 'paypal_capture', sprintf( __( 'PayPal capture did not complete (status: %s).', 'event-booking-pro' ), $status ) );
		}

		$capture_id = '';
		if ( ! empty( $result['purchase_units'][0]['payments']['captures'][0]['id'] ) ) {
			$capture_id = $result['purchase_units'][0]['payments']['captures'][0]['id'];
		}

		return array( 'capture_id' => $capture_id );
	}
}
