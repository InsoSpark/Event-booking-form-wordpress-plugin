<?php
/**
 * Booking custom post type + admin list management + details meta box.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Post_Types {

	const POST_TYPE = 'ebp_booking';

	/**
	 * Hook everything up.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );

		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( $this, 'columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
		add_filter( 'manage_edit-' . self::POST_TYPE . '_sortable_columns', array( $this, 'sortable_columns' ) );
		add_action( 'restrict_manage_posts', array( $this, 'status_filter' ), 10, 2 );
		add_action( 'pre_get_posts', array( $this, 'filter_by_status' ) );
		add_action( 'pre_get_posts', array( $this, 'search_by_reg_no' ) );
	}

	/**
	 * Register the booking post type.
	 */
	public function register() {
		$labels = array(
			'name'               => __( 'Bookings', 'event-booking-pro' ),
			'singular_name'      => __( 'Booking', 'event-booking-pro' ),
			'add_new'            => __( 'Add New', 'event-booking-pro' ),
			'add_new_item'       => __( 'Add New Booking', 'event-booking-pro' ),
			'edit_item'          => __( 'Edit Booking', 'event-booking-pro' ),
			'new_item'           => __( 'New Booking', 'event-booking-pro' ),
			'view_item'          => __( 'View Booking', 'event-booking-pro' ),
			'search_items'       => __( 'Search Bookings', 'event-booking-pro' ),
			'not_found'          => __( 'No bookings found.', 'event-booking-pro' ),
			'not_found_in_trash' => __( 'No bookings found in Trash.', 'event-booking-pro' ),
			'all_items'          => __( 'Bookings', 'event-booking-pro' ),
		);

		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => $labels,
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => 'ebp-settings',
				'show_in_rest'        => false,
				'capability_type'     => 'post',
				'capabilities'        => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'        => true,
				'supports'            => array( 'title' ),
				'hierarchical'        => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
			)
		);
	}

	/**
	 * Admin list columns.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function columns( $columns ) {
		$new = array(
			'cb'        => $columns['cb'],
			'reg_no'    => __( 'Reg No', 'event-booking-pro' ),
			'name'      => __( 'Name', 'event-booking-pro' ),
			'email'     => __( 'Email', 'event-booking-pro' ),
			'headcount' => __( 'Headcount', 'event-booking-pro' ),
			'total'     => __( 'Total', 'event-booking-pro' ),
			'plan'      => __( 'Plan', 'event-booking-pro' ),
			'gateway'   => __( 'Gateway', 'event-booking-pro' ),
			'status'    => __( 'Status', 'event-booking-pro' ),
			'date'      => $columns['date'],
		);
		return $new;
	}

	/**
	 * Render custom column content.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 */
	public function column_content( $column, $post_id ) {
		$data = EBP_Booking::get_data( $post_id );
		$edit = get_edit_post_link( $post_id );

		switch ( $column ) {
			case 'reg_no':
				$reg = isset( $data['reg_no'] ) ? $data['reg_no'] : '—';
				printf( '<a href="%s"><strong>%s</strong></a>', esc_url( $edit ), esc_html( $reg ) );
				break;

			case 'name':
				$name = trim( ( isset( $data['first_name'] ) ? $data['first_name'] : '' ) . ' ' . ( isset( $data['last_name'] ) ? $data['last_name'] : '' ) );
				echo esc_html( $name ? $name : '—' );
				break;

			case 'email':
				$email = isset( $data['email'] ) ? $data['email'] : '';
				echo $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '—';
				break;

			case 'headcount':
				echo isset( $data['headcount'] ) ? esc_html( $data['headcount'] ) : '—';
				break;

			case 'total':
				echo isset( $data['totals']['total'] ) ? esc_html( ebp_money( $data['totals']['total'] ) ) : '—';
				break;

			case 'plan':
				echo isset( $data['plan_label'] ) ? esc_html( $data['plan_label'] ) : '—';
				break;

			case 'gateway':
				$gateway = isset( $data['payment']['gateway'] ) ? $data['payment']['gateway'] : '';
				echo $gateway ? esc_html( ucfirst( $gateway ) ) : '—';
				break;

			case 'status':
				$status = get_post_meta( $post_id, '_ebp_status', true );
				$status = $status ? $status : 'pending';
				$label  = EBP_Booking::status_label( $status );
				printf( '<span class="ebp-status ebp-status-%s">%s</span>', esc_attr( $status ), esc_html( $label ) );
				break;
		}
	}

	/**
	 * Sortable columns.
	 *
	 * @param array $columns Sortable columns.
	 * @return array
	 */
	public function sortable_columns( $columns ) {
		$columns['date'] = 'date';
		return $columns;
	}

	/**
	 * Status filter dropdown on the bookings list.
	 *
	 * @param string $post_type Post type.
	 * @param string $which     Location (top/bottom).
	 */
	public function status_filter( $post_type, $which ) {
		if ( self::POST_TYPE !== $post_type || 'top' !== $which ) {
			return;
		}
		$current = isset( $_GET['ebp_status'] ) ? sanitize_key( wp_unslash( $_GET['ebp_status'] ) ) : '';
		$options = EBP_Booking::status_options();
		echo '<select name="ebp_status">';
		echo '<option value="">' . esc_html__( 'All statuses', 'event-booking-pro' ) . '</option>';
		foreach ( $options as $value => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $value ), selected( $current, $value, false ), esc_html( $label ) );
		}
		echo '</select>';
	}

	/**
	 * Filter the bookings list by status.
	 *
	 * @param WP_Query $query The query.
	 */
	public function filter_by_status( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || self::POST_TYPE !== $query->get( 'post_type' ) ) {
			return;
		}
		$status = isset( $_GET['ebp_status'] ) ? sanitize_key( wp_unslash( $_GET['ebp_status'] ) ) : '';
		if ( $status && array_key_exists( $status, EBP_Booking::status_options() ) ) {
			$meta = $query->get( 'meta_query' );
			if ( ! is_array( $meta ) ) {
				$meta = array();
			}
			$meta[] = array(
				'key'   => '_ebp_status',
				'value' => $status,
			);
			$query->set( 'meta_query', $meta );
		}
	}

	/**
	 * Allow searching by registration number in the admin search.
	 *
	 * @param WP_Query $query The query.
	 */
	public function search_by_reg_no( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || empty( $query->query_vars['s'] ) || self::POST_TYPE !== $query->get( 'post_type' ) ) {
			return;
		}
		$search = sanitize_text_field( $query->query_vars['s'] );
		$meta   = $query->get( 'meta_query' );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}
		$meta[] = array(
			'relation' => 'OR',
			array(
				'key'     => '_ebp_data',
				'value'   => $search,
				'compare' => 'LIKE',
			),
			array(
				'key'   => '_ebp_reg_no',
				'value' => $search,
			),
		);
		$query->set( 'meta_query', $meta );
	}

	/**
	 * Register the booking details meta box.
	 */
	public function add_meta_box() {
		add_meta_box(
			'ebp_booking_details',
			__( 'Booking Details', 'event-booking-pro' ),
			array( $this, 'render_meta_box' ),
			self::POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * Render the booking details meta box.
	 *
	 * @param WP_Post $post Post object.
	 */
	public function render_meta_box( $post ) {
		$data   = EBP_Booking::get_data( $post->ID );
		$status = get_post_meta( $post->ID, '_ebp_status', true );
		$status = $status ? $status : 'pending';

		wp_nonce_field( 'ebp_admin_booking', 'ebp_admin_nonce' );

		echo '<div class="ebp-admin-booking">';

		echo '<p class="ebp-admin-reg">' . esc_html__( 'Registration No:', 'event-booking-pro' ) . ' <strong>' . esc_html( isset( $data['reg_no'] ) ? $data['reg_no'] : '—' ) . '</strong></p>';

		echo '<table class="widefat striped ebp-admin-table">';
		$rows = array(
			__( 'Primary Registrant', 'event-booking-pro' ) => ( isset( $data['first_name'] ) ? $data['first_name'] : '' ) . ' ' . ( isset( $data['last_name'] ) ? $data['last_name'] : '' ),
			__( 'Email', 'event-booking-pro' )              => isset( $data['email'] ) ? $data['email'] : '',
			__( 'Phone', 'event-booking-pro' )              => isset( $data['phone'] ) ? $data['phone'] : '—',
			__( 'Branch / Connection', 'event-booking-pro' ) => isset( $data['branch'] ) ? $data['branch'] : '—',
			__( 'Mailing Address', 'event-booking-pro' )    => isset( $data['address'] ) ? $data['address'] : '—',
			__( 'Headcount', 'event-booking-pro' )          => isset( $data['headcount'] ) ? $data['headcount'] : '—',
			__( 'Reservation Total', 'event-booking-pro' )  => isset( $data['totals']['total'] ) ? ebp_money( $data['totals']['total'] ) : '—',
			__( 'Due Today', 'event-booking-pro' )          => isset( $data['totals']['due'] ) ? ebp_money( $data['totals']['due'] ) : '—',
			__( 'Remaining Balance', 'event-booking-pro' )  => isset( $data['totals']['balance'] ) ? ebp_money( $data['totals']['balance'] ) : '—',
			__( 'Payment Plan', 'event-booking-pro' )       => isset( $data['plan_label'] ) ? $data['plan_label'] : '—',
			__( 'Gateway', 'event-booking-pro' )            => ( isset( $data['payment']['gateway'] ) && $data['payment']['gateway'] ) ? ucfirst( $data['payment']['gateway'] ) : '—',
			__( 'Transaction ID', 'event-booking-pro' )     => ( isset( $data['payment']['transaction_id'] ) && $data['payment']['transaction_id'] ) ? $data['payment']['transaction_id'] : '—',
			__( 'Paid Date', 'event-booking-pro' )          => ( isset( $data['payment']['paid_date'] ) && $data['payment']['paid_date'] ) ? $data['payment']['paid_date'] : '—',
		);
		foreach ( $rows as $label => $value ) {
			echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( $value ) . '</td></tr>';
		}
		echo '</table>';

		if ( ! empty( $data['packages'] ) ) {
			echo '<h4>' . esc_html__( 'Packages', 'event-booking-pro' ) . '</h4>';
			echo '<table class="widefat striped ebp-admin-table">';
			echo '<tr><th>' . esc_html__( 'Package', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Price', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Qty', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Subtotal', 'event-booking-pro' ) . '</th></tr>';
			foreach ( $data['packages'] as $item ) {
				$sub = (float) $item['price'] * (int) $item['qty'];
				echo '<tr><td>' . esc_html( $item['name'] ) . '</td><td>' . esc_html( ebp_money( $item['price'] ) ) . '</td><td>' . esc_html( $item['qty'] ) . '</td><td>' . esc_html( ebp_money( $sub ) ) . '</td></tr>';
			}
			echo '</table>';
		}

		if ( ! empty( $data['addons'] ) ) {
			echo '<h4>' . esc_html__( 'Add-Ons', 'event-booking-pro' ) . '</h4>';
			echo '<table class="widefat striped ebp-admin-table">';
			echo '<tr><th>' . esc_html__( 'Add-On', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Price', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Qty', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Subtotal', 'event-booking-pro' ) . '</th></tr>';
			foreach ( $data['addons'] as $item ) {
				$sub = (float) $item['price'] * (int) $item['qty'];
				echo '<tr><td>' . esc_html( $item['name'] ) . '</td><td>' . esc_html( ebp_money( $item['price'] ) ) . '</td><td>' . esc_html( $item['qty'] ) . '</td><td>' . esc_html( ebp_money( $sub ) ) . '</td></tr>';
			}
			echo '</table>';
		}

		if ( ! empty( $data['attendees'] ) ) {
			echo '<h4>' . esc_html__( 'Attendees', 'event-booking-pro' ) . '</h4>';
			echo '<table class="widefat striped ebp-admin-table">';
			echo '<tr><th>' . esc_html__( 'Name', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Age Group', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Shirt Size', 'event-booking-pro' ) . '</th><th>' . esc_html__( 'Meal / Allergy', 'event-booking-pro' ) . '</th></tr>';
			foreach ( $data['attendees'] as $a ) {
				echo '<tr><td>' . esc_html( ( isset( $a['first'] ) ? $a['first'] : '' ) . ' ' . ( isset( $a['last'] ) ? $a['last'] : '' ) ) . '</td><td>' . esc_html( isset( $a['age_group'] ) ? $a['age_group'] : '—' ) . '</td><td>' . esc_html( isset( $a['shirt_size'] ) ? $a['shirt_size'] : '—' ) . '</td><td>' . esc_html( isset( $a['meal'] ) ? $a['meal'] : '—' ) . '</td></tr>';
			}
			echo '</table>';
		}

		echo '<div class="ebp-admin-actions">';
		echo '<label for="ebp-status">' . esc_html__( 'Status:', 'event-booking-pro' ) . '</label>';
		echo '<select id="ebp-status">';
		foreach ( EBP_Booking::status_options() as $value => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $value ), selected( $status, $value, false ), esc_html( $label ) );
		}
		echo '</select>';
		echo '<button type="button" class="button" id="ebp-save-status">' . esc_html__( 'Save Status', 'event-booking-pro' ) . '</button>';
		echo '<button type="button" class="button" data-ebp-resend="confirmation">' . esc_html__( 'Resend Confirmation Email', 'event-booking-pro' ) . '</button>';
		echo '<button type="button" class="button" data-ebp-resend="payment">' . esc_html__( 'Resend Payment Email', 'event-booking-pro' ) . '</button>';
		echo '<span class="spinner"></span><span class="ebp-admin-msg"></span>';
		echo '</div>';

		echo '</div>';
	}

	/**
	 * Load admin CSS/JS on the bookings screens.
	 *
	 * @param string $hook Current admin hook.
	 */
	public function admin_assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}
		if ( 'post' === $screen->base || 'edit' === $screen->base ) {
			wp_enqueue_style( 'ebp-admin', EBP_PLUGIN_URL . 'assets/css/admin.css', array(), EBP_VERSION );
			wp_enqueue_script( 'ebp-admin', EBP_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), EBP_VERSION, true );
			wp_localize_script(
				'ebp-admin',
				'EBP_ADMIN',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'ebp_admin' ),
					'postId'  => isset( $GLOBALS['post'] ) ? $GLOBALS['post']->ID : 0,
				)
			);
		}
	}
}
