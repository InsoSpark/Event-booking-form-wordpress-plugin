<?php
/**
 * Default plugin settings. Single source of truth used on activation,
 * when reading settings and during sanitization.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Settings_Defaults {

	/**
	 * Return the full default settings array.
	 *
	 * @return array
	 */
	public static function get() {
		return array(
			'general' => array(
				'event_name'         => 'Cross Culture Family Reunion',
				'tagline'            => 'Register Your Family',
				'event_date'         => 'July 2 - 5, 2027',
				'venue_name'         => 'Lanier Islands Resort',
				'venue_address'      => '7000 Holiday Rd, Lake Lanier Islands, GA 30518',
				'reg_deadline'       => 'June 1, 2027',
				'reg_prefix'         => 'CC27',
				'earlybird_enabled'  => '1',
				'earlybird_date'     => 'May 1, 2027',
				'earlybird_savings'  => '$50 per adult',
				'currency_code'      => 'USD',
				'currency_symbol'    => '$',
				'refund_policy'      => 'Registration payments are refundable up to the registration deadline per the reunion refund policy.',
				'confirm_message'    => "We're registered for the {event_name}! Make sure your household registers before space fills up.",
			),
			'packages' => array(
				'packages' => array(
					array( 'name' => 'Adult (18-64)', 'price' => '175', 'desc' => 'Welcome celebration, banquet, picnic, t-shirt, reunion keepsake, family activities' ),
					array( 'name' => 'Teen (13-17)', 'price' => '125', 'desc' => 'All events plus teen-specific activities and teen night' ),
					array( 'name' => 'Child (4-12)', 'price' => '85', 'desc' => 'All events, children\'s meals and children\'s activities' ),
					array( 'name' => 'Toddler (0-3)', 'price' => '0', 'desc' => 'No charge - still register so we have an accurate headcount' ),
					array( 'name' => 'Senior (65+)', 'price' => '150', 'desc' => 'All events at the approved senior discount rate' ),
				),
				'addons' => array(
					array( 'name' => 'Extra Reunion T-Shirt', 'price' => '20', 'desc' => 'Each' ),
					array( 'name' => 'Family Souvenir Book', 'price' => '15', 'desc' => 'Each' ),
					array( 'name' => 'Additional Banquet Ticket', 'price' => '45', 'desc' => 'Each' ),
					array( 'name' => 'Family Photo Package', 'price' => '30', 'desc' => 'Each' ),
					array( 'name' => 'Reunion Donation / Legacy Sponsorship', 'price' => '25', 'desc' => 'Helps a family in need attend' ),
				),
			),
			'payment' => array(
				'plan_full'         => '1',
				'plan_deposit'      => '1',
				'plan_installment'  => '1',
				'deposit_percent'   => '25',
				'installment_count' => '3',
				'paypal_enabled'    => '0',
				'paypal_mode'       => 'sandbox',
				'paypal_client_id'  => '',
				'paypal_secret'     => '',
				'stripe_enabled'    => '0',
				'stripe_mode'       => 'test',
				'stripe_publishable'=> '',
				'stripe_secret'     => '',
			),
			'email' => array(
				'from_name'          => 'Event Booking Pro',
				'from_email'         => '',
				'admin_emails'       => '',
				'send_confirmation'  => '1',
				'send_payment'       => '1',
				'send_admin'         => '1',
				'subject_confirmation' => 'Booking Received - {event_name} ({reg_no})',
				'subject_payment'    => 'Payment Confirmed - {reg_no}',
				'subject_admin'      => 'New Booking: {reg_no} ({name})',
				'body_confirmation'  => self::default_confirmation_body(),
				'body_payment'       => self::default_payment_body(),
				'body_admin'         => self::default_admin_body(),
			),
			'appearance' => array(
				'primary_color'   => '#0B5FA5',
				'accent_color'    => '#F4B400',
				'background_color'=> '#F6EFE2',
				'button_color'    => '#0B5FA5',
				'font_family'     => 'montserrat',
				'show_earlybird'  => '1',
				'show_hotel_btn'  => '1',
				'hotel_url'       => '#',
				'custom_css'      => '',
			),
		);
	}

	/**
	 * Default confirmation email body.
	 *
	 * @return string
	 */
	private static function default_confirmation_body() {
		return "Hello {first_name},\n\nThank you for registering for the {event_name}!\n\nBooking Reference: {reg_no}\nReservation Total: {total}\nAmount Due Today: {due}\nPayment Plan: {plan_label}\n\n{package_summary}\n\nIf you have a balance remaining, please complete your payment to confirm your spot.\n\nVenue: {venue_name}\nEvent Date: {event_date}\nRegistration Deadline: {reg_deadline}\n\n{refund_policy}\n\nSee you there!\n{site_name}";
	}

	/**
	 * Default payment received email body.
	 *
	 * @return string
	 */
	private static function default_payment_body() {
		return "Hi {first_name},\n\nGreat news - your payment has been received and confirmed!\n\nBooking Reference: {reg_no}\nAmount Paid: {paid}\nPayment Method: {gateway_label}\nTransaction ID: {txn_id}\nReservation Total: {total}\nRemaining Balance: {balance}\n\nWe can't wait to see you at the {event_name} on {event_date}!\n\n{site_name}";
	}

	/**
	 * Default admin notification email body.
	 *
	 * @return string
	 */
	private static function default_admin_body() {
		return "New booking received:\n\nName: {name}\nEmail: {email}\nPhone: {phone}\nReg No: {reg_no}\nHeadcount: {headcount}\n\n{package_summary}\n\nTotal: {total}\nDue Today: {due}\nPlan: {plan_label}\nStatus: {status_label}\n\nManage booking: {admin_url}";
	}
}
