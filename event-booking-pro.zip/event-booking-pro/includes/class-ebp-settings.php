<?php
/**
 * Admin settings page: 5 tabs (General, Packages, Payment, Email, Appearance).
 * Everything is stored in one option (ebp_settings) and fully dynamic.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

class EBP_Settings {

	const OPTION = 'ebp_settings';

	/**
	 * @var string Current tab.
	 */
	private $tab = 'general';

	/**
	 * Hook everything up.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * Register the top-level menu page.
	 */
	public function menu() {
		add_menu_page(
			__( 'Event Booking Pro', 'event-booking-pro' ),
			__( 'Event Booking', 'event-booking-pro' ),
			'manage_options',
			'ebp-settings',
			array( $this, 'page' ),
			'dashicons-calendar-alt',
			26
		);
		add_submenu_page(
			'ebp-settings',
			__( 'Event Booking Pro Settings', 'event-booking-pro' ),
			__( 'Settings', 'event-booking-pro' ),
			'manage_options',
			'ebp-settings',
			array( $this, 'page' )
		);
	}

	/**
	 * Register the option with the Settings API.
	 */
	public function register() {
		register_setting( 'ebp_settings_group', self::OPTION, array( $this, 'sanitize' ) );
	}

	/**
	 * Load settings CSS/JS on the settings screen.
	 *
	 * @param string $hook Current admin hook.
	 */
	public function assets( $hook ) {
		if ( 'toplevel_page_ebp-settings' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'ebp-admin', EBP_PLUGIN_URL . 'assets/css/admin.css', array(), EBP_VERSION );
		wp_enqueue_script( 'ebp-admin', EBP_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker' ), EBP_VERSION, true );
	}

	/**
	 * Render the settings page.
	 */
	public function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$this->tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';
		$tabs      = array(
			'general'    => __( 'General', 'event-booking-pro' ),
			'packages'   => __( 'Packages & Add-Ons', 'event-booking-pro' ),
			'payment'    => __( 'Payment', 'event-booking-pro' ),
			'email'      => __( 'Email', 'event-booking-pro' ),
			'appearance' => __( 'Appearance', 'event-booking-pro' ),
		);
		?>
		<div class="wrap ebp-settings">
			<h1>Event Booking Pro <span class="ebp-version">v<?php echo esc_html( EBP_VERSION ); ?></span></h1>
			<p class="ebp-sub"><?php esc_html_e( 'Configure your event, pricing, payments and emails. Add the', 'event-booking-pro' ); ?> <code>[event_booking_pro]</code> <?php esc_html_e( 'shortcode to any page or post.', 'event-booking-pro' ); ?></p>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=ebp-settings&tab=' . $key ) ); ?>" class="nav-tab <?php echo $this->tab === $key ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</h2>

			<form method="post" action="options.php">
				<?php settings_fields( 'ebp_settings_group' ); ?>
				<?php
				switch ( $this->tab ) {
					case 'packages':
						$this->render_packages();
						break;
					case 'payment':
						$this->render_payment();
						break;
					case 'email':
						$this->render_email();
						break;
					case 'appearance':
						$this->render_appearance();
						break;
					default:
						$this->render_general();
				}
				?>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Tab renderers
	 * ------------------------------------------------------------------- */

	private function render_general() {
		$s = ebp_settings( 'general' );
		?>
		<table class="form-table ebp-table" role="presentation">
			<tr><th scope="row"><label for="ebp-event-name"><?php esc_html_e( 'Event Name', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-event-name" class="regular-text" name="ebp_settings[general][event_name]" value="<?php echo esc_attr( $s['event_name'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-tagline"><?php esc_html_e( 'Tagline', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-tagline" class="regular-text" name="ebp_settings[general][tagline]" value="<?php echo esc_attr( $s['tagline'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-event-date"><?php esc_html_e( 'Event Date', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-event-date" class="regular-text" name="ebp_settings[general][event_date]" value="<?php echo esc_attr( $s['event_date'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-venue-name"><?php esc_html_e( 'Venue Name', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-venue-name" class="regular-text" name="ebp_settings[general][venue_name]" value="<?php echo esc_attr( $s['venue_name'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-venue-address"><?php esc_html_e( 'Venue Address', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-venue-address" class="regular-text" name="ebp_settings[general][venue_address]" value="<?php echo esc_attr( $s['venue_address'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-reg-deadline"><?php esc_html_e( 'Registration Deadline', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-reg-deadline" class="regular-text" name="ebp_settings[general][reg_deadline]" value="<?php echo esc_attr( $s['reg_deadline'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-reg-prefix"><?php esc_html_e( 'Registration No Prefix', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-reg-prefix" class="regular-text" name="ebp_settings[general][reg_prefix]" value="<?php echo esc_attr( $s['reg_prefix'] ); ?>" />
				<p class="description"><?php esc_html_e( 'e.g. CC27 produces registration numbers like CC27-482910.', 'event-booking-pro' ); ?></p></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Early Bird Banner', 'event-booking-pro' ); ?></th>
				<td>
					<label><input type="checkbox" name="ebp_settings[general][earlybird_enabled]" value="1" <?php checked( '1', $s['earlybird_enabled'] ); ?> /> <?php esc_html_e( 'Show early-bird banner', 'event-booking-pro' ); ?></label><br/><br/>
					<label for="ebp-eb-date"><?php esc_html_e( 'Early-Bird Deadline', 'event-booking-pro' ); ?></label>
					<input type="text" id="ebp-eb-date" class="regular-text" name="ebp_settings[general][earlybird_date]" value="<?php echo esc_attr( $s['earlybird_date'] ); ?>" /><br/>
					<label for="ebp-eb-savings"><?php esc_html_e( 'Savings Text', 'event-booking-pro' ); ?></label>
					<input type="text" id="ebp-eb-savings" class="regular-text" name="ebp_settings[general][earlybird_savings]" value="<?php echo esc_attr( $s['earlybird_savings'] ); ?>" />
				</td></tr>
			<tr><th scope="row"><label for="ebp-currency-code"><?php esc_html_e( 'Currency Code', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-currency-code" class="small-text" maxlength="3" name="ebp_settings[general][currency_code]" value="<?php echo esc_attr( $s['currency_code'] ); ?>" />
				<p class="description"><?php esc_html_e( 'e.g. USD, EUR, GBP. PayPal and Stripe require a valid ISO code.', 'event-booking-pro' ); ?></p></td></tr>
			<tr><th scope="row"><label for="ebp-currency-symbol"><?php esc_html_e( 'Currency Symbol', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-currency-symbol" class="small-text" name="ebp_settings[general][currency_symbol]" value="<?php echo esc_attr( $s['currency_symbol'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-refund"><?php esc_html_e( 'Refund Policy Text', 'event-booking-pro' ); ?></label></th>
				<td><textarea id="ebp-refund" class="large-text" rows="3" name="ebp_settings[general][refund_policy]"><?php echo esc_textarea( $s['refund_policy'] ); ?></textarea></td></tr>
			<tr><th scope="row"><label for="ebp-confirm-msg"><?php esc_html_e( 'Confirmation Message', 'event-booking-pro' ); ?></label></th>
				<td><textarea id="ebp-confirm-msg" class="large-text" rows="3" name="ebp_settings[general][confirm_message]"><?php echo esc_textarea( $s['confirm_message'] ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Shown on the final confirmation screen. You may use {event_name}.', 'event-booking-pro' ); ?></p></td></tr>
		</table>
		<?php
	}

	private function render_packages() {
		$s = ebp_settings( 'packages' );
		?>
		<h3><?php esc_html_e( 'Registration Packages', 'event-booking-pro' ); ?></h3>
		<p class="description"><?php esc_html_e( 'These appear on Step 3 with quantity steppers. Add, remove or reorder any number of packages.', 'event-booking-pro' ); ?></p>
		<div class="ebp-repeater" data-repeater="packages">
			<div class="ebp-rows" data-rows>
				<?php foreach ( $s['packages'] as $i => $pkg ) : ?>
					<div class="ebp-row" data-row>
						<div class="ebp-row-head">
							<span class="dashicons dashicons-menu ebp-drag"></span>
							<strong class="ebp-row-title"><?php echo esc_html( $pkg['name'] ); ?></strong>
							<button type="button" class="button-link ebp-remove" data-remove>✕</button>
						</div>
						<div class="ebp-row-fields">
							<div class="ebp-f"><label><?php esc_html_e( 'Name', 'event-booking-pro' ); ?></label><input type="text" class="regular-text ebp-row-name" name="ebp_settings[packages][packages][<?php echo esc_attr( $i ); ?>][name]" value="<?php echo esc_attr( $pkg['name'] ); ?>" /></div>
							<div class="ebp-f ebp-f-price"><label><?php esc_html_e( 'Price', 'event-booking-pro' ); ?></label><input type="text" class="small-text" name="ebp_settings[packages][packages][<?php echo esc_attr( $i ); ?>][price]" value="<?php echo esc_attr( $pkg['price'] ); ?>" /></div>
							<div class="ebp-f ebp-f-wide"><label><?php esc_html_e( 'Description', 'event-booking-pro' ); ?></label><input type="text" class="large-text" name="ebp_settings[packages][packages][<?php echo esc_attr( $i ); ?>][desc]" value="<?php echo esc_attr( $pkg['desc'] ); ?>" /></div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<button type="button" class="button" data-add><?php esc_html_e( '+ Add Package', 'event-booking-pro' ); ?></button>
			<template data-template style="display:none;">
				<div class="ebp-row" data-row>
					<div class="ebp-row-head">
						<span class="dashicons dashicons-menu ebp-drag"></span>
						<strong class="ebp-row-title"><?php esc_html_e( 'New Package', 'event-booking-pro' ); ?></strong>
						<button type="button" class="button-link ebp-remove" data-remove>✕</button>
					</div>
					<div class="ebp-row-fields">
						<div class="ebp-f"><label><?php esc_html_e( 'Name', 'event-booking-pro' ); ?></label><input type="text" class="regular-text ebp-row-name" name="ebp_settings[packages][packages][__i__][name]" value="" /></div>
						<div class="ebp-f ebp-f-price"><label><?php esc_html_e( 'Price', 'event-booking-pro' ); ?></label><input type="text" class="small-text" name="ebp_settings[packages][packages][__i__][price]" value="0" /></div>
						<div class="ebp-f ebp-f-wide"><label><?php esc_html_e( 'Description', 'event-booking-pro' ); ?></label><input type="text" class="large-text" name="ebp_settings[packages][packages][__i__][desc]" value="" /></div>
					</div>
				</div>
			</template>
		</div>

		<h3><?php esc_html_e( 'Add-Ons', 'event-booking-pro' ); ?></h3>
		<p class="description"><?php esc_html_e( 'Optional extras shown below the packages on Step 3.', 'event-booking-pro' ); ?></p>
		<div class="ebp-repeater" data-repeater="addons">
			<div class="ebp-rows" data-rows>
				<?php foreach ( $s['addons'] as $i => $addon ) : ?>
					<div class="ebp-row" data-row>
						<div class="ebp-row-head">
							<span class="dashicons dashicons-menu ebp-drag"></span>
							<strong class="ebp-row-title"><?php echo esc_html( $addon['name'] ); ?></strong>
							<button type="button" class="button-link ebp-remove" data-remove>✕</button>
						</div>
						<div class="ebp-row-fields">
							<div class="ebp-f"><label><?php esc_html_e( 'Name', 'event-booking-pro' ); ?></label><input type="text" class="regular-text ebp-row-name" name="ebp_settings[packages][addons][<?php echo esc_attr( $i ); ?>][name]" value="<?php echo esc_attr( $addon['name'] ); ?>" /></div>
							<div class="ebp-f ebp-f-price"><label><?php esc_html_e( 'Price', 'event-booking-pro' ); ?></label><input type="text" class="small-text" name="ebp_settings[packages][addons][<?php echo esc_attr( $i ); ?>][price]" value="<?php echo esc_attr( $addon['price'] ); ?>" /></div>
							<div class="ebp-f ebp-f-wide"><label><?php esc_html_e( 'Description', 'event-booking-pro' ); ?></label><input type="text" class="large-text" name="ebp_settings[packages][addons][<?php echo esc_attr( $i ); ?>][desc]" value="<?php echo esc_attr( $addon['desc'] ); ?>" /></div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<button type="button" class="button" data-add><?php esc_html_e( '+ Add Add-On', 'event-booking-pro' ); ?></button>
			<template data-template style="display:none;">
				<div class="ebp-row" data-row>
					<div class="ebp-row-head">
						<span class="dashicons dashicons-menu ebp-drag"></span>
						<strong class="ebp-row-title"><?php esc_html_e( 'New Add-On', 'event-booking-pro' ); ?></strong>
						<button type="button" class="button-link ebp-remove" data-remove>✕</button>
					</div>
					<div class="ebp-row-fields">
						<div class="ebp-f"><label><?php esc_html_e( 'Name', 'event-booking-pro' ); ?></label><input type="text" class="regular-text ebp-row-name" name="ebp_settings[packages][addons][__i__][name]" value="" /></div>
						<div class="ebp-f ebp-f-price"><label><?php esc_html_e( 'Price', 'event-booking-pro' ); ?></label><input type="text" class="small-text" name="ebp_settings[packages][addons][__i__][price]" value="0" /></div>
						<div class="ebp-f ebp-f-wide"><label><?php esc_html_e( 'Description', 'event-booking-pro' ); ?></label><input type="text" class="large-text" name="ebp_settings[packages][addons][__i__][desc]" value="" /></div>
					</div>
				</div>
			</template>
		</div>
		<?php
	}

	private function render_payment() {
		$p = ebp_settings( 'payment' );
		?>
		<h3><?php esc_html_e( 'Payment Plans', 'event-booking-pro' ); ?></h3>
		<table class="form-table ebp-table" role="presentation">
			<tr><th scope="row"><?php esc_html_e( 'Available Plans', 'event-booking-pro' ); ?></th>
				<td>
					<label><input type="checkbox" name="ebp_settings[payment][plan_full]" value="1" <?php checked( '1', $p['plan_full'] ); ?> /> <?php esc_html_e( 'Pay in Full', 'event-booking-pro' ); ?></label><br/>
					<label><input type="checkbox" name="ebp_settings[payment][plan_deposit]" value="1" <?php checked( '1', $p['plan_deposit'] ); ?> /> <?php esc_html_e( 'Deposit', 'event-booking-pro' ); ?></label><br/>
					<label><input type="checkbox" name="ebp_settings[payment][plan_installment]" value="1" <?php checked( '1', $p['plan_installment'] ); ?> /> <?php esc_html_e( 'Installment Plan', 'event-booking-pro' ); ?></label>
				</td></tr>
			<tr><th scope="row"><label for="ebp-deposit"><?php esc_html_e( 'Deposit Percent', 'event-booking-pro' ); ?></label></th>
				<td><input type="number" min="1" max="100" step="1" id="ebp-deposit" class="small-text" name="ebp_settings[payment][deposit_percent]" value="<?php echo esc_attr( $p['deposit_percent'] ); ?>" /> %</td></tr>
			<tr><th scope="row"><label for="ebp-installments"><?php esc_html_e( 'Installment Count', 'event-booking-pro' ); ?></label></th>
				<td><input type="number" min="2" max="12" step="1" id="ebp-installments" class="small-text" name="ebp_settings[payment][installment_count]" value="<?php echo esc_attr( $p['installment_count'] ); ?>" /></td></tr>
		</table>

		<hr/>

		<h3>PayPal</h3>
		<p class="description"><?php esc_html_e( 'Enable PayPal and paste your REST App Client ID and Secret. No webhooks required — payments are captured immediately at checkout.', 'event-booking-pro' ); ?></p>
		<table class="form-table ebp-table" role="presentation">
			<tr><th scope="row"><?php esc_html_e( 'Enable PayPal', 'event-booking-pro' ); ?></th>
				<td><label><input type="checkbox" name="ebp_settings[payment][paypal_enabled]" value="1" <?php checked( '1', $p['paypal_enabled'] ); ?> /> <?php esc_html_e( 'Accept PayPal payments', 'event-booking-pro' ); ?></label></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Mode', 'event-booking-pro' ); ?></th>
				<td>
					<label><input type="radio" name="ebp_settings[payment][paypal_mode]" value="sandbox" <?php checked( 'sandbox', $p['paypal_mode'] ); ?> /> <?php esc_html_e( 'Sandbox (test)', 'event-booking-pro' ); ?></label>&nbsp;&nbsp;
					<label><input type="radio" name="ebp_settings[payment][paypal_mode]" value="live" <?php checked( 'live', $p['paypal_mode'] ); ?> /> <?php esc_html_e( 'Live', 'event-booking-pro' ); ?></label>
				</td></tr>
			<tr><th scope="row"><label for="ebp-pp-id"><?php esc_html_e( 'Client ID', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-pp-id" class="regular-text ebp-secret" name="ebp_settings[payment][paypal_client_id]" value="<?php echo esc_attr( $p['paypal_client_id'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-pp-secret"><?php esc_html_e( 'Secret Key', 'event-booking-pro' ); ?></label></th>
				<td><input type="password" id="ebp-pp-secret" class="regular-text ebp-secret" name="ebp_settings[payment][paypal_secret]" value="<?php echo esc_attr( $p['paypal_secret'] ); ?>" /></td></tr>
		</table>

		<hr/>

		<h3>Stripe</h3>
		<p class="description"><?php esc_html_e( 'Enable Stripe and paste your Publishable and Secret keys. An embedded card form accepts Visa, Mastercard, Amex and more. No webhooks required.', 'event-booking-pro' ); ?></p>
		<table class="form-table ebp-table" role="presentation">
			<tr><th scope="row"><?php esc_html_e( 'Enable Stripe', 'event-booking-pro' ); ?></th>
				<td><label><input type="checkbox" name="ebp_settings[payment][stripe_enabled]" value="1" <?php checked( '1', $p['stripe_enabled'] ); ?> /> <?php esc_html_e( 'Accept credit / debit cards via Stripe', 'event-booking-pro' ); ?></label></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Mode', 'event-booking-pro' ); ?></th>
				<td>
					<label><input type="radio" name="ebp_settings[payment][stripe_mode]" value="test" <?php checked( 'test', $p['stripe_mode'] ); ?> /> <?php esc_html_e( 'Test', 'event-booking-pro' ); ?></label>&nbsp;&nbsp;
					<label><input type="radio" name="ebp_settings[payment][stripe_mode]" value="live" <?php checked( 'live', $p['stripe_mode'] ); ?> /> <?php esc_html_e( 'Live', 'event-booking-pro' ); ?></label>
				</td></tr>
			<tr><th scope="row"><label for="ebp-st-pk"><?php esc_html_e( 'Publishable Key', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-st-pk" class="regular-text ebp-secret" name="ebp_settings[payment][stripe_publishable]" value="<?php echo esc_attr( $p['stripe_publishable'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-st-sk"><?php esc_html_e( 'Secret Key', 'event-booking-pro' ); ?></label></th>
				<td><input type="password" id="ebp-st-sk" class="regular-text ebp-secret" name="ebp_settings[payment][stripe_secret]" value="<?php echo esc_attr( $p['stripe_secret'] ); ?>" /></td></tr>
		</table>
		<?php
	}

	private function render_email() {
		$e = ebp_settings( 'email' );
		?>
		<table class="form-table ebp-table" role="presentation">
			<tr><th scope="row"><label for="ebp-from-name"><?php esc_html_e( 'From Name', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-from-name" class="regular-text" name="ebp_settings[email][from_name]" value="<?php echo esc_attr( $e['from_name'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-from-email"><?php esc_html_e( 'From Email', 'event-booking-pro' ); ?></label></th>
				<td><input type="email" id="ebp-from-email" class="regular-text" name="ebp_settings[email][from_email]" value="<?php echo esc_attr( $e['from_email'] ); ?>" />
				<p class="description"><?php esc_html_e( 'Leave blank to use the site admin email.', 'event-booking-pro' ); ?></p></td></tr>
			<tr><th scope="row"><label for="ebp-admin-emails"><?php esc_html_e( 'Admin Notification Emails', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-admin-emails" class="large-text" name="ebp_settings[email][admin_emails]" value="<?php echo esc_attr( $e['admin_emails'] ); ?>" />
				<p class="description"><?php esc_html_e( 'Comma separated. Leave blank to use the site admin email.', 'event-booking-pro' ); ?></p></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Send Emails', 'event-booking-pro' ); ?></th>
				<td>
					<label><input type="checkbox" name="ebp_settings[email][send_confirmation]" value="1" <?php checked( '1', $e['send_confirmation'] ); ?> /> <?php esc_html_e( 'Booking confirmation (customer)', 'event-booking-pro' ); ?></label><br/>
					<label><input type="checkbox" name="ebp_settings[email][send_payment]" value="1" <?php checked( '1', $e['send_payment'] ); ?> /> <?php esc_html_e( 'Payment received (customer)', 'event-booking-pro' ); ?></label><br/>
					<label><input type="checkbox" name="ebp_settings[email][send_admin]" value="1" <?php checked( '1', $e['send_admin'] ); ?> /> <?php esc_html_e( 'Admin notification (new booking)', 'event-booking-pro' ); ?></label>
				</td></tr>
		</table>

		<?php
		$types = array(
			'confirmation' => __( 'Booking Confirmation', 'event-booking-pro' ),
			'payment'      => __( 'Payment Received', 'event-booking-pro' ),
			'admin'        => __( 'Admin Notification', 'event-booking-pro' ),
		);
		foreach ( $types as $key => $label ) :
			?>
			<h3><?php echo esc_html( $label ); ?></h3>
			<table class="form-table ebp-table" role="presentation">
				<tr><th scope="row"><label for="ebp-sub-<?php echo esc_attr( $key ); ?>"><?php esc_html_e( 'Subject', 'event-booking-pro' ); ?></label></th>
					<td><input type="text" id="ebp-sub-<?php echo esc_attr( $key ); ?>" class="large-text" name="ebp_settings[email][subject_<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $e[ 'subject_' . $key ] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="ebp-body-<?php echo esc_attr( $key ); ?>"><?php esc_html_e( 'Body', 'event-booking-pro' ); ?></label></th>
					<td><textarea id="ebp-body-<?php echo esc_attr( $key ); ?>" class="large-text" rows="12" name="ebp_settings[email][body_<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $e[ 'body_' . $key ] ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Available placeholders:', 'event-booking-pro' ); ?> {event_name} {event_date} {venue_name} {venue_address} {reg_deadline} {reg_no} {name} {first_name} {last_name} {email} {phone} {branch} {headcount} {total} {due} {paid} {balance} {plan_label} {gateway_label} {txn_id} {status_label} {package_summary} {addon_summary} {attendees_list} {refund_policy} {admin_url} {site_name} {site_url}</p></td></tr>
			</table>
		<?php endforeach; ?>
		<?php
	}

	private function render_appearance() {
		$a = ebp_settings( 'appearance' );
		?>
		<table class="form-table ebp-table" role="presentation">
			<tr><th scope="row"><label for="ebp-color-primary"><?php esc_html_e( 'Primary Color', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-color-primary" class="ebp-color" name="ebp_settings[appearance][primary_color]" value="<?php echo esc_attr( $a['primary_color'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-color-accent"><?php esc_html_e( 'Accent Color', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-color-accent" class="ebp-color" name="ebp_settings[appearance][accent_color]" value="<?php echo esc_attr( $a['accent_color'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-color-bg"><?php esc_html_e( 'Background Color', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-color-bg" class="ebp-color" name="ebp_settings[appearance][background_color]" value="<?php echo esc_attr( $a['background_color'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-color-btn"><?php esc_html_e( 'Button Color', 'event-booking-pro' ); ?></label></th>
				<td><input type="text" id="ebp-color-btn" class="ebp-color" name="ebp_settings[appearance][button_color]" value="<?php echo esc_attr( $a['button_color'] ); ?>" /></td></tr>
			<tr><th scope="row"><label for="ebp-font"><?php esc_html_e( 'Font Family', 'event-booking-pro' ); ?></label></th>
				<td>
					<select id="ebp-font" name="ebp_settings[appearance][font_family]">
						<option value="montserrat" <?php selected( 'montserrat', $a['font_family'] ); ?>><?php esc_html_e( 'Montserrat + Playfair Display', 'event-booking-pro' ); ?></option>
						<option value="lora" <?php selected( 'lora', $a['font_family'] ); ?>><?php esc_html_e( 'Lora + Poppins', 'event-booking-pro' ); ?></option>
						<option value="system" <?php selected( 'system', $a['font_family'] ); ?>><?php esc_html_e( 'System Fonts', 'event-booking-pro' ); ?></option>
					</select>
				</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Early-Bird Banner', 'event-booking-pro' ); ?></th>
				<td><label><input type="checkbox" name="ebp_settings[appearance][show_earlybird]" value="1" <?php checked( '1', $a['show_earlybird'] ); ?> /> <?php esc_html_e( 'Show on booking form', 'event-booking-pro' ); ?></label></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Book Hotel Button', 'event-booking-pro' ); ?></th>
				<td>
					<label><input type="checkbox" name="ebp_settings[appearance][show_hotel_btn]" value="1" <?php checked( '1', $a['show_hotel_btn'] ); ?> /> <?php esc_html_e( 'Show on confirmation screen', 'event-booking-pro' ); ?></label><br/>
					<label for="ebp-hotel-url"><?php esc_html_e( 'Hotel / Booking URL', 'event-booking-pro' ); ?></label>
					<input type="url" id="ebp-hotel-url" class="regular-text" name="ebp_settings[appearance][hotel_url]" value="<?php echo esc_attr( $a['hotel_url'] ); ?>" />
				</td></tr>
			<tr><th scope="row"><label for="ebp-css"><?php esc_html_e( 'Custom CSS', 'event-booking-pro' ); ?></label></th>
				<td><textarea id="ebp-css" class="large-text" rows="8" name="ebp_settings[appearance][custom_css]"><?php echo esc_textarea( $a['custom_css'] ); ?></textarea></td></tr>
		</table>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Sanitization
	 * ------------------------------------------------------------------- */

	/**
	 * Sanitize the whole settings array before saving.
	 *
	 * @param mixed $input Submitted value.
	 * @return array
	 */
	public function sanitize( $input ) {
		$defaults = EBP_Settings_Defaults::get();
		$saved    = get_option( self::OPTION, array() );
		$current  = array_replace_recursive( $defaults, is_array( $saved ) ? $saved : array() );
		if ( ! is_array( $input ) ) {
			return $current;
		}

		$clean = $current;

		// General.
		if ( isset( $input['general'] ) && is_array( $input['general'] ) ) {
			$g = $input['general'];
			$clean['general'] = array(
				'event_name'        => sanitize_text_field( isset( $g['event_name'] ) ? $g['event_name'] : $defaults['general']['event_name'] ),
				'tagline'           => sanitize_text_field( isset( $g['tagline'] ) ? $g['tagline'] : '' ),
				'event_date'        => sanitize_text_field( isset( $g['event_date'] ) ? $g['event_date'] : '' ),
				'venue_name'        => sanitize_text_field( isset( $g['venue_name'] ) ? $g['venue_name'] : '' ),
				'venue_address'     => sanitize_text_field( isset( $g['venue_address'] ) ? $g['venue_address'] : '' ),
				'reg_deadline'      => sanitize_text_field( isset( $g['reg_deadline'] ) ? $g['reg_deadline'] : '' ),
				'reg_prefix'        => sanitize_text_field( isset( $g['reg_prefix'] ) ? $g['reg_prefix'] : 'EBP' ),
				'earlybird_enabled' => isset( $g['earlybird_enabled'] ) ? '1' : '0',
				'earlybird_date'    => sanitize_text_field( isset( $g['earlybird_date'] ) ? $g['earlybird_date'] : '' ),
				'earlybird_savings' => sanitize_text_field( isset( $g['earlybird_savings'] ) ? $g['earlybird_savings'] : '' ),
				'currency_code'     => strtoupper( substr( sanitize_text_field( isset( $g['currency_code'] ) ? $g['currency_code'] : 'USD' ), 0, 3 ) ),
				'currency_symbol'   => sanitize_text_field( isset( $g['currency_symbol'] ) ? $g['currency_symbol'] : '$' ),
				'refund_policy'     => sanitize_textarea_field( isset( $g['refund_policy'] ) ? $g['refund_policy'] : '' ),
				'confirm_message'   => sanitize_textarea_field( isset( $g['confirm_message'] ) ? $g['confirm_message'] : '' ),
			);
		}

		// Packages & add-ons (repeatable).
		if ( isset( $input['packages'] ) && is_array( $input['packages'] ) ) {
			$clean['packages']['packages'] = $this->clean_rows( isset( $input['packages']['packages'] ) ? $input['packages']['packages'] : array() );
			$clean['packages']['addons']   = $this->clean_rows( isset( $input['packages']['addons'] ) ? $input['packages']['addons'] : array() );
		}

		// Payment.
		if ( isset( $input['payment'] ) && is_array( $input['payment'] ) ) {
			$pay = $input['payment'];
			$clean['payment'] = array(
				'plan_full'         => isset( $pay['plan_full'] ) ? '1' : '0',
				'plan_deposit'      => isset( $pay['plan_deposit'] ) ? '1' : '0',
				'plan_installment'  => isset( $pay['plan_installment'] ) ? '1' : '0',
				'deposit_percent'   => max( 1, min( 100, (int) ( isset( $pay['deposit_percent'] ) ? $pay['deposit_percent'] : 25 ) ) ),
				'installment_count' => max( 2, min( 12, (int) ( isset( $pay['installment_count'] ) ? $pay['installment_count'] : 3 ) ) ),
				'paypal_enabled'    => isset( $pay['paypal_enabled'] ) ? '1' : '0',
				'paypal_mode'       => isset( $pay['paypal_mode'] ) && 'live' === $pay['paypal_mode'] ? 'live' : 'sandbox',
				'paypal_client_id'  => sanitize_text_field( isset( $pay['paypal_client_id'] ) ? $pay['paypal_client_id'] : '' ),
				'paypal_secret'     => sanitize_text_field( isset( $pay['paypal_secret'] ) ? $pay['paypal_secret'] : '' ),
				'stripe_enabled'    => isset( $pay['stripe_enabled'] ) ? '1' : '0',
				'stripe_mode'       => isset( $pay['stripe_mode'] ) && 'live' === $pay['stripe_mode'] ? 'live' : 'test',
				'stripe_publishable'=> sanitize_text_field( isset( $pay['stripe_publishable'] ) ? $pay['stripe_publishable'] : '' ),
				'stripe_secret'     => sanitize_text_field( isset( $pay['stripe_secret'] ) ? $pay['stripe_secret'] : '' ),
			);
		}

		// Email.
		if ( isset( $input['email'] ) && is_array( $input['email'] ) ) {
			$em = $input['email'];
			$clean['email'] = array(
				'from_name'          => sanitize_text_field( isset( $em['from_name'] ) ? $em['from_name'] : '' ),
				'from_email'         => sanitize_email( isset( $em['from_email'] ) ? $em['from_email'] : '' ),
				'admin_emails'       => sanitize_text_field( isset( $em['admin_emails'] ) ? $em['admin_emails'] : '' ),
				'send_confirmation'  => isset( $em['send_confirmation'] ) ? '1' : '0',
				'send_payment'       => isset( $em['send_payment'] ) ? '1' : '0',
				'send_admin'         => isset( $em['send_admin'] ) ? '1' : '0',
				'subject_confirmation' => sanitize_text_field( isset( $em['subject_confirmation'] ) ? $em['subject_confirmation'] : '' ),
				'subject_payment'    => sanitize_text_field( isset( $em['subject_payment'] ) ? $em['subject_payment'] : '' ),
				'subject_admin'      => sanitize_text_field( isset( $em['subject_admin'] ) ? $em['subject_admin'] : '' ),
				'body_confirmation'  => sanitize_textarea_field( isset( $em['body_confirmation'] ) ? $em['body_confirmation'] : '' ),
				'body_payment'       => sanitize_textarea_field( isset( $em['body_payment'] ) ? $em['body_payment'] : '' ),
				'body_admin'         => sanitize_textarea_field( isset( $em['body_admin'] ) ? $em['body_admin'] : '' ),
			);
		}

		// Appearance.
		if ( isset( $input['appearance'] ) && is_array( $input['appearance'] ) ) {
			$ap = $input['appearance'];
			$clean['appearance'] = array(
				'primary_color'   => sanitize_hex_color( isset( $ap['primary_color'] ) ? $ap['primary_color'] : $defaults['appearance']['primary_color'] ),
				'accent_color'    => sanitize_hex_color( isset( $ap['accent_color'] ) ? $ap['accent_color'] : $defaults['appearance']['accent_color'] ),
				'background_color'=> sanitize_hex_color( isset( $ap['background_color'] ) ? $ap['background_color'] : $defaults['appearance']['background_color'] ),
				'button_color'    => sanitize_hex_color( isset( $ap['button_color'] ) ? $ap['button_color'] : $defaults['appearance']['button_color'] ),
				'font_family'     => in_array( isset( $ap['font_family'] ) ? $ap['font_family'] : '', array( 'montserrat', 'lora', 'system' ), true ) ? $ap['font_family'] : 'montserrat',
				'show_earlybird'  => isset( $ap['show_earlybird'] ) ? '1' : '0',
				'show_hotel_btn'  => isset( $ap['show_hotel_btn'] ) ? '1' : '0',
				'hotel_url'       => esc_url_raw( isset( $ap['hotel_url'] ) ? $ap['hotel_url'] : '#' ),
				'custom_css'      => sanitize_textarea_field( isset( $ap['custom_css'] ) ? $ap['custom_css'] : '' ),
			);
			// Fall back to defaults when a color picker came back empty.
			foreach ( array( 'primary_color', 'accent_color', 'background_color', 'button_color' ) as $c ) {
				if ( ! $clean['appearance'][ $c ] ) {
					$clean['appearance'][ $c ] = $defaults['appearance'][ $c ];
				}
			}
		}

		return $clean;
	}

	/**
	 * Clean repeatable package/add-on rows.
	 *
	 * @param array $rows Raw rows.
	 * @return array
	 */
	private function clean_rows( $rows ) {
		$clean = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name  = sanitize_text_field( isset( $row['name'] ) ? $row['name'] : '' );
			$price = (float) ( isset( $row['price'] ) ? $row['price'] : 0 );
			$desc  = sanitize_text_field( isset( $row['desc'] ) ? $row['desc'] : '' );
			if ( '' === $name ) {
				continue;
			}
			$clean[] = array(
				'name'  => $name,
				'price' => $price,
				'desc'  => $desc,
			);
		}
		return $clean;
	}
}
