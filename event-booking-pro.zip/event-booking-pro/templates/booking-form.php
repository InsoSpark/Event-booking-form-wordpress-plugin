<?php
/**
 * Booking form template. Rendered by the [event_booking_pro] shortcode.
 *
 * Available variables: $settings, $packages, $addons, $plans, $gateways,
 * $style, $paypal, $stripe.
 *
 * @package EventBookingPro
 */

defined( 'ABSPATH' ) || exit;

$g = $settings['general'];
?>
<div class="ebp-wrap" style="<?php echo $style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">

	<section class="ebp-register" id="ebp-register">
		<div class="ebp-inner">
			<div class="ebp-section-head ebp-center">
				<div class="ebp-eyebrow"><?php echo esc_html( $g['tagline'] ); ?></div>
				<h2><?php echo esc_html( $g['event_name'] ); ?></h2>
				<p><?php echo esc_html( $g['venue_name'] ); ?> &middot; <?php echo esc_html( $g['event_date'] ); ?></p>
			</div>

			<?php if ( '1' === (string) $settings['appearance']['show_earlybird'] && '1' === (string) $g['earlybird_enabled'] ) : ?>
				<div class="ebp-earlybird">🌅 <?php echo esc_html__( 'Register by', 'event-booking-pro' ); ?> <?php echo esc_html( $g['earlybird_date'] ); ?> <?php echo esc_html__( 'and save', 'event-booking-pro' ); ?> <?php echo esc_html( $g['earlybird_savings'] ); ?>. <?php echo esc_html__( 'Price increases after the deadline.', 'event-booking-pro' ); ?></div>
			<?php endif; ?>

			<div class="ebp-wizard">
				<div class="ebp-progress" id="ebp-progress">
					<div class="ebp-seg done"></div><div class="ebp-seg"></div><div class="ebp-seg"></div><div class="ebp-seg"></div>
				</div>

				<div class="ebp-error" id="ebp-error"></div>

				<!-- STEP 1 -->
				<div class="ebp-step active" data-step="1">
					<div class="ebp-step-label"><?php esc_html_e( 'Step 1 of 4', 'event-booking-pro' ); ?></div>
					<div class="ebp-step-title"><?php esc_html_e( 'Select Your Household', 'event-booking-pro' ); ?></div>
					<div class="ebp-field-row">
						<div class="ebp-field"><label><?php esc_html_e( 'Primary Registrant First Name', 'event-booking-pro' ); ?></label><input type="text" id="ebp-first" placeholder="<?php esc_attr_e( 'Jordan', 'event-booking-pro' ); ?>" /></div>
						<div class="ebp-field"><label><?php esc_html_e( 'Last Name', 'event-booking-pro' ); ?></label><input type="text" id="ebp-last" placeholder="<?php esc_attr_e( 'Cross', 'event-booking-pro' ); ?>" /></div>
					</div>
					<div class="ebp-field"><label><?php esc_html_e( 'Family Branch or Connection', 'event-booking-pro' ); ?></label>
						<select id="ebp-branch">
							<?php
							$branches = array( __( 'Bishop Family', 'event-booking-pro' ), __( 'Alexander Family', 'event-booking-pro' ), __( 'Charles Family', 'event-booking-pro' ), __( 'Francis Family', 'event-booking-pro' ), __( 'Other / New Branch', 'event-booking-pro' ) );
							foreach ( $branches as $branch ) {
								echo '<option>' . esc_html( $branch ) . '</option>';
							}
							?>
						</select>
					</div>
					<div class="ebp-field-row">
						<div class="ebp-field"><label><?php esc_html_e( 'Email Address', 'event-booking-pro' ); ?></label><input type="email" id="ebp-email" placeholder="you@example.com" /></div>
						<div class="ebp-field"><label><?php esc_html_e( 'Phone Number', 'event-booking-pro' ); ?></label><input type="tel" id="ebp-phone" placeholder="(555) 555-5555" /></div>
					</div>
					<div class="ebp-field"><label><?php esc_html_e( 'Mailing Address', 'event-booking-pro' ); ?></label><input type="text" id="ebp-address" placeholder="<?php esc_attr_e( 'Street, City, State, ZIP', 'event-booking-pro' ); ?>" /></div>
					<div class="ebp-nav"><span></span><button class="ebp-btn ebp-btn-primary" onclick="EBPnextStep(1)"><?php esc_html_e( 'Continue', 'event-booking-pro' ); ?></button></div>
				</div>

				<!-- STEP 2 -->
				<div class="ebp-step" data-step="2">
					<div class="ebp-step-label"><?php esc_html_e( 'Step 2 of 4', 'event-booking-pro' ); ?></div>
					<div class="ebp-step-title"><?php esc_html_e( 'Add Attendees', 'event-booking-pro' ); ?></div>
					<div id="ebp-members"></div>
					<button type="button" class="ebp-add-member" onclick="EBPaddMember()">+ <?php esc_html_e( 'Add Attendee', 'event-booking-pro' ); ?></button>
					<div class="ebp-nav"><button class="ebp-btn ebp-btn-ghost" onclick="EBPprevStep(2)"><?php esc_html_e( 'Back', 'event-booking-pro' ); ?></button><button class="ebp-btn ebp-btn-primary" onclick="EBPnextStep(2)"><?php esc_html_e( 'Continue', 'event-booking-pro' ); ?></button></div>
				</div>

				<!-- STEP 3 -->
				<div class="ebp-step" data-step="3">
					<div class="ebp-step-label"><?php esc_html_e( 'Step 3 of 4', 'event-booking-pro' ); ?></div>
					<div class="ebp-step-title"><?php esc_html_e( 'Registration Packages & Add-Ons', 'event-booking-pro' ); ?></div>
					<div class="ebp-pkg-grid" id="ebp-packages">
						<?php foreach ( $packages as $i => $pkg ) : ?>
							<div class="ebp-pkg">
								<div class="ebp-pk-row"><h4><?php echo esc_html( $pkg['name'] ); ?></h4><span class="ebp-price" data-price="<?php echo esc_attr( $pkg['price'] ); ?>"><?php echo esc_html( 0 === (float) $pkg['price'] ? __( 'Free', 'event-booking-pro' ) : ebp_money( $pkg['price'] ) ); ?></span></div>
								<p class="ebp-incl"><?php echo esc_html( $pkg['desc'] ); ?></p>
								<div class="ebp-qty"><button type="button" onclick="EBPchQty('pkg_<?php echo esc_attr( $i ); ?>',-1)">−</button><span id="ebp-q-pkg_<?php echo esc_attr( $i ); ?>">0</span><button type="button" onclick="EBPchQty('pkg_<?php echo esc_attr( $i ); ?>',1)">+</button></div>
							</div>
						<?php endforeach; ?>
					</div>

					<h3 class="ebp-addon-heading"><?php esc_html_e( 'Optional Add-Ons', 'event-booking-pro' ); ?></h3>
					<?php foreach ( $addons as $i => $addon ) : ?>
						<div class="ebp-addon-row">
							<div class="ebp-info"><h4><?php echo esc_html( $addon['name'] ); ?></h4><p><?php echo esc_html( $addon['desc'] ); ?> &middot; <?php echo esc_html( ebp_money( $addon['price'] ) ); ?></p></div>
							<div class="ebp-qty"><button type="button" onclick="EBPchAddon('addon_<?php echo esc_attr( $i ); ?>',-1)">−</button><span id="ebp-a-addon_<?php echo esc_attr( $i ); ?>">0</span><button type="button" onclick="EBPchAddon('addon_<?php echo esc_attr( $i ); ?>',1)">+</button></div>
						</div>
					<?php endforeach; ?>

					<div class="ebp-total-box"><div class="ebp-grand"><span><?php esc_html_e( 'Estimated Total', 'event-booking-pro' ); ?></span><span id="ebp-runningTotal"><?php echo esc_html( ebp_money( 0 ) ); ?></span></div></div>
					<div class="ebp-nav"><button class="ebp-btn ebp-btn-ghost" onclick="EBPprevStep(3)"><?php esc_html_e( 'Back', 'event-booking-pro' ); ?></button><button class="ebp-btn ebp-btn-primary" onclick="EBPnextStep(3)"><?php esc_html_e( 'Continue', 'event-booking-pro' ); ?></button></div>
				</div>

				<!-- STEP 4 -->
				<div class="ebp-step" data-step="4">
					<div class="ebp-step-label"><?php esc_html_e( 'Step 4 of 4', 'event-booking-pro' ); ?></div>
					<div class="ebp-step-title"><?php esc_html_e( 'Payment', 'event-booking-pro' ); ?></div>

					<div class="ebp-pay-options" id="ebp-payOptions">
						<?php if ( in_array( 'full', $plans, true ) ) : ?>
							<button type="button" class="ebp-pay-opt sel" data-plan="full" onclick="EBPselectPlan('full')"><h4><?php esc_html_e( 'Pay in Full', 'event-booking-pro' ); ?></h4><p><?php esc_html_e( 'One payment today', 'event-booking-pro' ); ?></p></button>
						<?php endif; ?>
						<?php if ( in_array( 'deposit', $plans, true ) ) : ?>
							<button type="button" class="ebp-pay-opt" data-plan="deposit" onclick="EBPselectPlan('deposit')"><h4><?php esc_html_e( 'Deposit', 'event-booking-pro' ); ?></h4><p><?php echo esc_html( sprintf( __( '%d%% now, rest by final deadline', 'event-booking-pro' ), (int) $settings['payment']['deposit_percent'] ) ); ?></p></button>
						<?php endif; ?>
						<?php if ( in_array( 'installment', $plans, true ) ) : ?>
							<button type="button" class="ebp-pay-opt" data-plan="installment" onclick="EBPselectPlan('installment')"><h4><?php esc_html_e( 'Installment Plan', 'event-booking-pro' ); ?></h4><p><?php echo esc_html( sprintf( __( 'Split into %d approved payments', 'event-booking-pro' ), (int) $settings['payment']['installment_count'] ) ); ?></p></button>
						<?php endif; ?>
					</div>

					<div class="ebp-gateway-options" id="ebp-gateways">
						<?php if ( $stripe->is_configured() ) : ?>
							<button type="button" class="ebp-gateway-opt" data-gateway="stripe" onclick="EBPselectGateway('stripe')"><span class="ebp-gw-dot"></span><div><h4><?php esc_html_e( 'Credit / Debit Card', 'event-booking-pro' ); ?></h4><p><?php esc_html_e( 'Visa, Mastercard, Amex and more', 'event-booking-pro' ); ?></p></div></button>
						<?php endif; ?>
						<?php if ( $paypal->is_configured() ) : ?>
							<button type="button" class="ebp-gateway-opt" data-gateway="paypal" onclick="EBPselectGateway('paypal')"><span class="ebp-gw-dot"></span><div><h4><?php esc_html_e( 'PayPal', 'event-booking-pro' ); ?></h4><p><?php esc_html_e( 'Pay with your PayPal balance or a card', 'event-booking-pro' ); ?></p></div></button>
						<?php endif; ?>
					</div>

					<div class="ebp-gateway-panel ebp-stripe-panel" id="ebp-stripe-panel">
						<div class="ebp-card-element" id="ebp-card-element"></div>
						<div class="ebp-card-errors" id="ebp-card-errors"></div>
					</div>
					<div class="ebp-gateway-panel ebp-paypal-panel" id="ebp-paypal-panel">
						<div id="ebp-paypal-buttons"></div>
					</div>

					<div class="ebp-total-box">
						<div class="ebp-row"><span><?php esc_html_e( 'Due Today', 'event-booking-pro' ); ?></span><span id="ebp-dueToday"><?php echo esc_html( ebp_money( 0 ) ); ?></span></div>
						<div class="ebp-row"><span><?php esc_html_e( 'Remaining Balance', 'event-booking-pro' ); ?></span><span id="ebp-remBalance"><?php echo esc_html( ebp_money( 0 ) ); ?></span></div>
						<div class="ebp-grand"><span><?php esc_html_e( 'Reservation Total', 'event-booking-pro' ); ?></span><span id="ebp-finalTotal"><?php echo esc_html( ebp_money( 0 ) ); ?></span></div>
					</div>

					<?php if ( '' !== $g['refund_policy'] ) : ?>
						<p class="ebp-refund-note"><?php echo esc_html( $g['refund_policy'] ); ?></p>
					<?php endif; ?>

					<div class="ebp-nav"><button class="ebp-btn ebp-btn-ghost" onclick="EBPprevStep(4)"><?php esc_html_e( 'Back', 'event-booking-pro' ); ?></button><button class="ebp-btn ebp-btn-primary" id="ebp-submit" onclick="EBPsubmitRegistration()"><?php esc_html_e( 'Complete Registration', 'event-booking-pro' ); ?></button></div>
				</div>

				<!-- STEP 5 -->
				<div class="ebp-step" data-step="5">
					<div class="ebp-confirm">
						<div class="ebp-check">✓</div>
						<h3><?php esc_html_e( "You're Registered!", 'event-booking-pro' ); ?></h3>
						<div class="ebp-regno" id="ebp-regNo"></div>
						<div class="ebp-confirm-details" id="ebp-confirmDetails"></div>
						<div class="ebp-confirm-actions">
							<button type="button" class="ebp-btn ebp-btn-primary" onclick="window.print()"><?php esc_html_e( 'Print Receipt', 'event-booking-pro' ); ?></button>
							<?php if ( '1' === (string) $settings['appearance']['show_hotel_btn'] ) : ?>
								<a href="<?php echo esc_url( $settings['appearance']['hotel_url'] ); ?>" class="ebp-btn ebp-btn-gold" target="_blank" rel="noopener"><?php esc_html_e( 'Book Hotel', 'event-booking-pro' ); ?></a>
							<?php endif; ?>
						</div>
						<div class="ebp-confirm-referral" id="ebp-confirmMessage"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
